# macOS 资料库自适应网格 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 让瀑布流和卡片模式使用受限宽度的自适应列数，而非将少量卡片拉满资料库宽度。

**Architecture:** 新增纯 Swift 的 `AdaptiveGridLayout`，由它针对资料库可用宽度计算列数、单卡宽度和网格总宽度。`LibraryView` 通过 `GeometryReader` 使用固定宽度 `GridItem` 渲染并将网格居中；阅读器的中栏降级规则保持不变。

**Tech Stack:** Swift 6、SwiftUI、XCTest。

## Global Constraints

- 仅修改 macOS 资料库展示层、UI Lab 场景和 macOS 文档/单测。
- 瀑布流为竖向上图下字卡：封面宽高比 `0.75`，单卡目标宽度 `220–300 pt`，间距 `16 pt`，最多 4 列。
- 卡片为矮胖横向上封面下文卡：封面宽高比 `2.35`，单卡目标宽度 `360–520 pt`，间距 `16 pt`，最多 3 列。
- 窄窗口允许单卡小于目标最小宽度以避免横向滚动；正常可用宽度内必须遵守最小/最大宽度与列数上限。
- 选中文章时，中栏仍通过 `PresentationMode.resolved(hasSelectedArticle:)` 强制为左图右文列表。
- 使用 TDD：每项布局计算先有失败测试，再写最小实现。

---

### Task 1: 可测试的自适应网格计算器

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryPagination.swift`
- Modify: `apps/macos/QiankunjieMacTests/CoreContractTests.swift`

**Interfaces:**
- Produces: `AdaptiveGridLayout(minItemWidth:maxItemWidth:spacing:maxColumns:)`
- Produces: `AdaptiveGridLayout.frame(for:) -> AdaptiveGridFrame`
- `AdaptiveGridFrame` exposes `columnCount: Int`, `itemWidth: Double`, `contentWidth: Double`.

- [ ] **Step 1: Write failing layout tests**

```swift
func testAdaptiveGridCapsCardWidthAndAddsColumnsInsteadOfStretching() {
    let waterfall = LibraryCardLayout.waterfall.grid.frame(for: 1_280)
    XCTAssertEqual(waterfall.columnCount, 4)
    XCTAssertEqual(waterfall.itemWidth, 300, accuracy: 0.001)

    let card = LibraryCardLayout.card.grid.frame(for: 1_600)
    XCTAssertEqual(card.columnCount, 3)
    XCTAssertEqual(card.itemWidth, 520, accuracy: 0.001)
}
```

- [ ] **Step 2: Run `pnpm macos:test` and verify the test fails because `grid` is absent.**
- [ ] **Step 3: Implement `AdaptiveGridLayout` and clamp normal widths to the configured maximum.**
- [ ] **Step 4: Run `pnpm macos:test` and verify the new test passes.**

### Task 2: 竖向瀑布流与横向卡片渲染

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryPagination.swift`
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryView.swift`
- Modify: `apps/macos/QiankunjieMacTests/CoreContractTests.swift`

**Interfaces:**
- Consumes: `LibraryCardLayout.waterfall.grid` and `LibraryCardLayout.card.grid`.
- Produces: `AdaptiveArticleGrid(layout:content:)` and preserves `WaterfallArticleCard`, `StandardArticleCard`.

- [ ] **Step 1: Extend the failing tests** to assert `waterfall.coverAspectRatio == 0.75`, waterfall uses at most four columns, card uses at most three columns, and a 600 pt waterfall content width resolves to two columns.
- [ ] **Step 2: Run `pnpm macos:test` and verify the new assertions fail against the existing fixed two-column / 1.36 waterfall rules.**
- [ ] **Step 3: Set the new card constraints and replace the fixed `.flexible()` grid with an `AdaptiveArticleGrid` that uses fixed `GridItem` widths and centers its bounded content width.**
- [ ] **Step 4: Run `pnpm macos:test`; verify all tests pass.**

### Task 3: UI Lab and documentation verification

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/UILab/UILabScenario.swift`
- Modify: `apps/macos/README.md`
- Modify: `docs/MACOS-NATIVE-PARITY-MATRIX.md`

- [ ] **Step 1: Add enough UI Lab fixture articles to make 3–4 waterfall columns and 2–3 card columns visibly verifiable.**
- [ ] **Step 2: Start `waterfall` and `card` UI Lab scenes at the current desktop window size.**
- [ ] **Step 3: Capture and inspect both windows; verify waterfall cards remain portrait and card-mode cards remain bounded, horizontal and centered.**
- [ ] **Step 4: Document the adaptive width ranges, maximum columns and reader fallback.**
- [ ] **Step 5: Run `pnpm macos:test`, `pnpm macos:build`, and whitespace checks for tracked and untracked files.**
