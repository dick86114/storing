# macOS 资料库三种展示模式 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 macOS 资料库展示模式明确为左图右文列表、Android 风格双列上图下字瀑布流、统一封面比例的上图下字卡片。

**Architecture:** 在 `LibraryView` 中拆分三种独立的文章展示组件。以一个无 UI 副作用的布局规则类型锁定模式语义和阅读器中栏降级行为；瀑布流、卡片共用封面加载/占位组件，但分别使用自然内容高度与固定摘要/封面规则。

**Tech Stack:** Swift 6、SwiftUI、XCTest、现有 `ArticleCard` DTO、`AsyncImage`。

## Global Constraints

- 仅修改 `apps/macos` 的资料库展示层和 macOS 单测。
- 瀑布流严格参照 Android `QiankunjieGridArticleCard`：上图下字、约 1.36:1 封面、无封面仍使用同结构占位。
- 列表必须保持左图右文。
- 选中阅读器文章时，中栏必须继续降级为紧凑列表。
- 不修改 API、Android 客户端或现有缓存模型。
- 使用 TDD：先写失败测试，再写最小实现。

---

### Task 1: 锁定展示模式语义

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryPagination.swift`
- Modify: `apps/macos/QiankunjieMacTests/CoreContractTests.swift`

**Interfaces:**
- Produces: `AppModel.PresentationMode.resolved(hasSelectedArticle:)`
- Produces: `LibraryCardLayout` 的封面比例和摘要行数规则。

- [ ] **Step 1: Write the failing test** — 断言 `list`、`grid`、`card` 各自保留身份，且选中文章时统一解析为 `.list`；断言瀑布流和卡片使用不同摘要限制。
- [ ] **Step 2: Run test to verify it fails**
- [ ] **Step 3: Add the minimal layout rule type and resolver**
- [ ] **Step 4: Run the targeted test to verify it passes**

### Task 2: 实现 Android 风格双列瀑布卡片

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryView.swift`
- Modify: `apps/macos/QiankunjieMacTests/CoreContractTests.swift`

**Interfaces:**
- Consumes: `LibraryCardLayout.waterfall`
- Produces: `WaterfallArticleCard` 和两列 `LazyVGrid`。

- [ ] **Step 1: Write the failing test** — 验证瀑布流布局使用 Android 对齐的 1.36 封面比例和上图下字规则。
- [ ] **Step 2: Run test to verify it fails**
- [ ] **Step 3: Implement shared cover view plus waterfall card** — 固定封面比例，封面缺失时保留图形占位；下方显示来源、标题、单个标签，摘要只在有空间时显示。
- [ ] **Step 4: Replace current `.grid` content with adaptive two-column grid**
- [ ] **Step 5: Run macOS tests**

### Task 3: 实现规则卡片和左图右文列表

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/Library/LibraryView.swift`
- Modify: `apps/macos/QiankunjieMacTests/CoreContractTests.swift`

**Interfaces:**
- Consumes: `LibraryCardLayout.card` and `.list`
- Produces: `StandardArticleCard` and `ArticleListRow`.

- [ ] **Step 1: Write the failing test** — 验证卡片与瀑布流的摘要限制不同，列表保留横向缩略图尺寸。
- [ ] **Step 2: Run test to verify it fails**
- [ ] **Step 3: Implement standard card** — 上方统一比例封面、下方标题和受限摘要。
- [ ] **Step 4: Replace native `List` row with left-image/right-text list row**
- [ ] **Step 5: Run macOS tests**

### Task 4: UI Lab 视觉验收

**Files:**
- Modify: `apps/macos/QiankunjieMac/Features/UILab/UILabScenario.swift` only if extra fixture data is necessary
- Verify: `scripts/macos-ui-lab.sh`

- [ ] **Step 1: Build and launch library UI Lab**
- [ ] **Step 2: Capture list, waterfall and card screenshots**
- [ ] **Step 3: Confirm selected-reader middle column remains a compact list**
- [ ] **Step 4: Run `pnpm macos:test`, `pnpm macos:build`, and `git diff --check`**
