import assert from 'node:assert/strict';
import test from 'node:test';
import { authRoutes } from '../src/routes/auth.js';
import { collectRoutes } from '../src/routes/collect.js';

test('native auth aliases are registered without replacing mobile aliases', async () => {
  const nativeResponse = await authRoutes.request('/native/auth/sessions');
  const mobileResponse = await authRoutes.request('/mobile/auth/sessions');
  assert.equal(nativeResponse.status, 401);
  assert.equal(mobileResponse.status, 401);
});

test('native collect aliases are registered without replacing mobile aliases', async () => {
  const nativeResponse = await collectRoutes.request('/native/collect/jobs');
  const mobileResponse = await collectRoutes.request('/mobile/collect/jobs');
  assert.equal(nativeResponse.status, 401);
  assert.equal(mobileResponse.status, 401);
});

test('native login rejects missing platform before touching persistence', async () => {
  const response = await authRoutes.request('/native/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      username: 'demo',
      password: 'password',
      device: {
        deviceId: '3a7c0d2b-f9f2-4b64-a87e-453d4a24c5fe',
        deviceName: 'Mac',
        appVersion: '0.1.0',
      },
    }),
  });
  assert.equal(response.status, 400);
  const body = await response.json() as { error?: { code?: string } };
  assert.equal(body.error?.code, 'BAD_REQUEST');
});
