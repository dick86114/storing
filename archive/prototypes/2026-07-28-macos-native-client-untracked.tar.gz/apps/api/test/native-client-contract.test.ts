import assert from 'node:assert/strict';
import test from 'node:test';
import jwt from 'jsonwebtoken';
import {
  collectSourcesForPlatform,
  parseNativePlatform,
  validateNativeCollectSource,
} from '../src/services/native-client-contract.js';
import { validateNativeDevice } from '../src/services/mobile-session.service.js';
import { generateNativeAccessToken } from '../src/middleware/auth.js';

test('native platforms are explicit and reject unknown clients', () => {
  assert.equal(parseNativePlatform('android'), 'android');
  assert.equal(parseNativePlatform('macos'), 'macos');
  assert.throws(() => parseNativePlatform('ios'), /客户端平台无效/);
});

test('native device validation preserves platform metadata', () => {
  assert.deepEqual(validateNativeDevice({
    deviceId: '3a7c0d2b-f9f2-4b64-a87e-453d4a24c5fe',
    deviceName: 'Dickies MacBook Air',
    appVersion: '0.1.0',
    platform: 'macos',
  }), {
    deviceId: '3a7c0d2b-f9f2-4b64-a87e-453d4a24c5fe',
    deviceName: 'Dickies MacBook Air',
    appVersion: '0.1.0',
    platform: 'macos',
  });
});

test('native collect sources are platform-scoped', () => {
  assert.deepEqual(collectSourcesForPlatform('android'), ['android', 'android_share']);
  assert.deepEqual(collectSourcesForPlatform('macos'), ['macos', 'macos_share', 'macos_browser']);
  assert.equal(validateNativeCollectSource('macos_browser', 'macos'), 'macos_browser');
  assert.throws(() => validateNativeCollectSource('android_share', 'macos'), /采集来源与客户端平台不匹配/);
});

test('native access tokens identify the platform while legacy Android tokens stay separate', () => {
  const token = generateNativeAccessToken(7, 'session-id', 'macos', 'test-secret-that-is-long-enough-for-tests');
  const payload = jwt.verify(token, 'test-secret-that-is-long-enough-for-tests') as jwt.JwtPayload;
  assert.equal(payload.userId, 7);
  assert.equal(payload.sessionId, 'session-id');
  assert.equal(payload.client, 'native');
  assert.equal(payload.platform, 'macos');
});
