export const NATIVE_PLATFORMS = ['android', 'macos'] as const;
export type NativePlatform = (typeof NATIVE_PLATFORMS)[number];

export const NATIVE_COLLECT_SOURCES = [
  'android',
  'android_share',
  'macos',
  'macos_share',
  'macos_browser',
] as const;
export type NativeCollectSource = (typeof NATIVE_COLLECT_SOURCES)[number];

const PLATFORM_COLLECT_SOURCES: Record<NativePlatform, readonly NativeCollectSource[]> = {
  android: ['android', 'android_share'],
  macos: ['macos', 'macos_share', 'macos_browser'],
};

export function parseNativePlatform(value: unknown): NativePlatform {
  if (value === 'android' || value === 'macos') return value;
  throw new Error('客户端平台无效');
}

export function collectSourcesForPlatform(platform: NativePlatform): NativeCollectSource[] {
  return [...PLATFORM_COLLECT_SOURCES[platform]];
}

export function validateNativeCollectSource(value: unknown, platform: NativePlatform): NativeCollectSource {
  if (typeof value !== 'string' || !NATIVE_COLLECT_SOURCES.includes(value as NativeCollectSource)) {
    throw new Error('采集来源无效');
  }
  const source = value as NativeCollectSource;
  if (!PLATFORM_COLLECT_SOURCES[platform].includes(source)) {
    throw new Error('采集来源与客户端平台不匹配');
  }
  return source;
}
