import AppKit
import UniformTypeIdentifiers

final class ShareViewController: NSViewController {
    private let statusLabel = NSTextField(labelWithString: "正在读取分享内容…")

    override func loadView() {
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 420, height: 160))
        statusLabel.alignment = .center
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 24),
            statusLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -24),
            statusLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),
        ])
        view = container
    }

    override func viewDidAppear() {
        super.viewDidAppear()
        Task { await processInput() }
    }

    @MainActor
    private func processInput() async {
        let items = extensionContext?.inputItems.compactMap { $0 as? NSExtensionItem } ?? []
        let providers = items.flatMap { $0.attachments ?? [] }
        var values: [String] = []
        for provider in providers {
            if provider.hasItemConformingToTypeIdentifier(UTType.url.identifier),
               let item = try? await provider.loadItem(forTypeIdentifier: UTType.url.identifier),
               let url = item as? URL {
                values.append(url.absoluteString)
            }
            if provider.hasItemConformingToTypeIdentifier(UTType.text.identifier),
               let item = try? await provider.loadItem(forTypeIdentifier: UTType.text.identifier),
               let text = item as? String {
                values.append(text)
            }
        }

        let title = items.compactMap { $0.attributedTitle?.string.nilIfEmpty }.first
        guard !values.isEmpty else {
            fail("没有找到可采集的链接")
            return
        }

        do {
            let store = try SharedCollectStore.appGroup()
            try store.removeExpired(olderThan: Date().addingTimeInterval(-24 * 60 * 60))
            let payloadID = try store.save(SharedCollectPayload(values: values, title: title))
            var components = URLComponents(string: "qiankunjie://collect")!
            components.queryItems = [
                URLQueryItem(name: "payload", value: payloadID.uuidString),
                URLQueryItem(name: "source", value: "share"),
            ]
            guard let deepLink = components.url, NSWorkspace.shared.open(deepLink) else {
                fail("无法打开乾坤戒")
                return
            }
            statusLabel.stringValue = "已发送到乾坤戒"
            extensionContext?.completeRequest(returningItems: nil)
        } catch {
            fail(error.localizedDescription)
        }
    }

    private func fail(_ message: String) {
        statusLabel.stringValue = message
        extensionContext?.cancelRequest(withError: NSError(domain: "QiankunjieShare", code: 1, userInfo: [NSLocalizedDescriptionKey: message]))
    }
}

private extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}
