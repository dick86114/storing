import SwiftData
import XCTest
@testable import QiankunjieMac

final class CoreContractTests: XCTestCase {
    func testIncomingCollectRouterExtractsAndDeduplicatesHTTPURLs() throws {
        let urls = IncomingCollectRouter.extractURLs(
            from: "先看 https://example.com/a，再看 https://example.com/a 和 http://example.org/post。"
        )
        XCTAssertEqual(urls.map(\.absoluteString), ["https://example.com/a", "http://example.org/post"])
    }

    func testIncomingCollectRouterRejectsNonWebSchemes() {
        XCTAssertEqual(IncomingCollectRouter.extractURLs(from: "file:///tmp/private mailto:user@example.com"), [])
    }

    func testDeepLinkRequiresCollectHostAndValidURL() throws {
        let deepLink = URL(string: "qiankunjie://collect?url=https%3A%2F%2Fexample.com%2Fpost&title=Example&source=browser")!
        let request = try IncomingCollectRouter.parseDeepLink(deepLink)
        XCTAssertEqual(request.urls.map(\.absoluteString), ["https://example.com/post"])
        XCTAssertEqual(request.title, "Example")
        XCTAssertEqual(request.source, .browser)
    }

    func testNativeDevicePayloadEncodesMacOSPlatform() throws {
        let payload = NativeDevicePayload(
            deviceId: UUID(uuidString: "3A7C0D2B-F9F2-4B64-A87E-453D4A24C5FE")!,
            deviceName: "MacBook Air",
            appVersion: "0.1.0"
        )
        let object = try JSONSerialization.jsonObject(with: JSONEncoder().encode(payload)) as! [String: Any]
        XCTAssertEqual(object["platform"] as? String, "macos")
    }

    func testSessionTokensRefreshThreshold() {
        let now = Date(timeIntervalSince1970: 1_000)
        let fresh = SessionTokens(accessToken: "a", accessTokenExpiresAt: now.addingTimeInterval(600), refreshToken: "r", refreshTokenExpiresAt: now.addingTimeInterval(3600), userId: 1)
        let stale = SessionTokens(accessToken: "a", accessTokenExpiresAt: now.addingTimeInterval(20), refreshToken: "r", refreshTokenExpiresAt: now.addingTimeInterval(3600), userId: 1)
        XCTAssertTrue(fresh.hasUsableAccessToken(at: now))
        XCTAssertFalse(stale.hasUsableAccessToken(at: now))
    }
}

extension CoreContractTests {
    func testAPIEndpointBuildsNativeAndArticleURLs() throws {
        XCTAssertEqual(APIEndpoint.nativeLogin.url.absoluteString, "https://storing.idickies.com/api/v1/native/auth/login")
        XCTAssertEqual(APIEndpoint.article(id: 42).url.absoluteString, "https://storing.idickies.com/api/v1/articles/42?format=html&htmlVariant=mobile")
    }

    func testArticleCardDecodesCurrentCamelCaseContract() throws {
        let data = Data(#"{"id":7,"title":"文章","originalUrl":"https://example.com","aiTags":["AI"],"isFavorited":true,"isArchived":false,"isPublished":true}"#.utf8)
        let article = try JSONDecoder.storing.decode(ArticleCard.self, from: data)
        XCTAssertEqual(article.id, 7)
        XCTAssertEqual(article.displayTitle, "文章")
        XCTAssertEqual(article.aiTags, ["AI"])
        XCTAssertTrue(article.isFavorited)
        XCTAssertTrue(article.isPublished)
    }
}

extension CoreContractTests {
    func testNativeEndpointsHaveLegacyMobileFallbacks() {
        XCTAssertEqual(APIEndpoint.nativeLogin.legacyMobileFallback, .mobileLogin)
        XCTAssertEqual(APIEndpoint.nativeRefresh.legacyMobileFallback, .mobileRefresh)
        XCTAssertEqual(APIEndpoint.nativeLogout.legacyMobileFallback, .mobileLogout)
        XCTAssertEqual(APIEndpoint.nativeCollect.legacyMobileFallback, .mobileCollect)
        XCTAssertEqual(APIEndpoint.collectJobs(limit: 30, offset: 0).legacyMobileFallback, .mobileCollectJobs(limit: 30, offset: 0))
    }

    func testLegacyCollectSourceMappingPreservesShareIntent() {
        XCTAssertEqual(CollectEntrySource.manual.legacyMobileValue, "android")
        XCTAssertEqual(CollectEntrySource.share.legacyMobileValue, "android_share")
        XCTAssertEqual(CollectEntrySource.browser.legacyMobileValue, "android_share")
    }
}

extension CoreContractTests {
    func testOfflineHTMLProcessorExtractsUniqueRemoteImagesAndRewritesToRelativeAssets() {
        let html = #"<p><img src="https://cdn.example.com/a.jpg"><img src='https://cdn.example.com/a.jpg'><img src="data:image/png;base64,abc"></p>"#
        XCTAssertEqual(OfflineHTMLProcessor.remoteImageURLs(in: html).map(\.absoluteString), ["https://cdn.example.com/a.jpg"])
        let rewritten = OfflineHTMLProcessor.rewrite(html: html, replacements: ["https://cdn.example.com/a.jpg": "images/a.jpg"])
        XCTAssertEqual(rewritten.components(separatedBy: "images/a.jpg").count - 1, 2)
        XCTAssertTrue(rewritten.contains("data:image/png;base64,abc"))
    }

    func testReaderPreferencesGenerateDeterministicCSS() {
        let preferences = ReaderPreferences(textScale: 1.15, lineHeight: 1.9, horizontalPadding: 36)
        let css = preferences.css
        XCTAssertTrue(css.contains("font-size:115%"))
        XCTAssertTrue(css.contains("line-height:1.90"))
        XCTAssertTrue(css.contains("padding:42px 36px"))
    }
}

extension CoreContractTests {
    func testPendingCollectPolicyOnlyQueuesConnectivityFailures() {
        XCTAssertTrue(PendingCollectPolicy.shouldQueue(URLError(.notConnectedToInternet)))
        XCTAssertTrue(PendingCollectPolicy.shouldQueue(URLError(.networkConnectionLost)))
        XCTAssertFalse(PendingCollectPolicy.shouldQueue(APIClientError.server(code: "BAD_REQUEST", message: "bad", status: 400)))
    }
}

extension CoreContractTests {
    func testUILabScenarioParsesStableLaunchArguments() {
        XCTAssertEqual(UILabScenario(arguments: ["app", "--ui-lab", "--ui-lab-scenario=reader"]), .reader)
        XCTAssertEqual(UILabScenario(arguments: ["app", "--ui-lab", "--ui-lab-scenario=waterfall"]), .waterfall)
        XCTAssertEqual(UILabScenario(arguments: ["app", "--ui-lab", "--ui-lab-scenario=card"]), .card)
        XCTAssertEqual(UILabScenario(arguments: ["app", "--ui-lab"]), .library)
    }
}

extension CoreContractTests {
    func testLibraryPaginationStopsAtLastPage() {
        var paging = LibraryPagination(page: 1, totalPages: 3)
        XCTAssertEqual(paging.nextPage(), 2)
        XCTAssertEqual(paging.nextPage(), 3)
        XCTAssertNil(paging.nextPage())
        paging.reset(totalPages: 1)
        XCTAssertNil(paging.nextPage())
    }

    func testArticleManagementEndpointsMatchServerContract() {
        XCTAssertEqual(APIEndpoint.sources.url.absoluteString, "https://storing.idickies.com/api/v1/sources")
        XCTAssertEqual(APIEndpoint.deleteArticle(id: 8).url.absoluteString, "https://storing.idickies.com/api/v1/articles/8")
        XCTAssertEqual(APIEndpoint.deleteArticlePermanently(id: 8).url.absoluteString, "https://storing.idickies.com/api/v1/articles/8/permanent")
    }
}

extension CoreContractTests {
    func testOfflineStoreCommitsPackageAndCanClearUserScope() async throws {
        let root = FileManager.default.temporaryDirectory.appending(path: "qk-offline-test-\(UUID().uuidString)")
        let store = OfflineArticleStore(root: root)
        let article = ArticleDetail(id: 77, title: "Offline", author: nil, source: "example.com", originalUrl: "https://example.com", publicId: nil, coverImage: nil, publishTime: nil, createdAt: nil, aiSummary: "summary", aiCategory: nil, aiTags: [], isFavorited: false, isArchived: true, isPublished: false, contentHtml: "<p>offline body</p>", contentMd: nil)
        let package = try await store.download(article: article, userId: 9)
        XCTAssertTrue(FileManager.default.fileExists(atPath: package.htmlFile.path))
        let saved = try await store.list(userId: 9)
        XCTAssertEqual(saved.map(\.id), [77])
        try await store.clear(userId: 9)
        let remaining = try await store.list(userId: 9)
        XCTAssertTrue(remaining.isEmpty)
    }

    func testSharePosterQRCodeCanBeRendered() {
        XCTAssertNotNil(QRCode.image(for: "https://storing.idickies.com/p/example"))
    }
}

extension CoreContractTests {
    func testSharedCollectPayloadResolvesAndDeduplicatesEverySharedWebURL() {
        let payload = SharedCollectPayload(
            values: [
                "第一篇 https://example.com/a 和第二篇 https://example.org/b",
                "https://example.com/a",
                "file:///tmp/private",
            ],
            title: "分享内容",
            createdAt: Date(timeIntervalSince1970: 100)
        )

        let request = payload.collectRequest
        XCTAssertEqual(request.urls.map(\.absoluteString), ["https://example.com/a", "https://example.org/b"])
        XCTAssertEqual(request.title, "分享内容")
        XCTAssertEqual(request.source, .share)
    }

    func testSharedCollectStoreConsumesPayloadExactlyOnce() throws {
        let root = FileManager.default.temporaryDirectory.appending(path: "qk-share-test-\(UUID().uuidString)")
        let store = SharedCollectStore(root: root)
        let payload = SharedCollectPayload(values: ["https://example.com/a"], title: nil, createdAt: Date(timeIntervalSince1970: 100))

        let id = try store.save(payload)
        XCTAssertEqual(try store.consume(id: id), payload)
        XCTAssertNil(try store.consume(id: id))
    }

    func testIncomingCollectRouterRecognizesAppGroupPayloadDeepLink() throws {
        let id = UUID(uuidString: "4F5CB4A7-2033-4E02-B25D-57DCE9823D52")!
        let target = try IncomingCollectRouter.parseDeepLinkTarget(
            URL(string: "qiankunjie://collect?payload=\(id.uuidString)&source=share")!
        )
        XCTAssertEqual(target, .sharedPayload(id))
    }
}

extension CoreContractTests {
    func testGlobalShortcutPresetsExposeStableCarbonRegistrationValues() {
        XCTAssertEqual(GlobalShortcutDescriptor.defaultPreset.id, "option-command-s")
        XCTAssertEqual(GlobalShortcutDescriptor.defaultPreset.displayName, "⌥⌘S")
        XCTAssertTrue(GlobalShortcutDescriptor.presets.contains { $0.id == "shift-command-s" && $0.displayName == "⇧⌘S" })
        XCTAssertEqual(GlobalShortcutDescriptor.preset(id: "missing"), .defaultPreset)
    }

    func testLaunchAtLoginStatusKeepsApprovalRequiredVisibleAsEnabled() {
        XCTAssertTrue(LaunchAtLoginStatus.enabled.isPresentedAsEnabled)
        XCTAssertTrue(LaunchAtLoginStatus.requiresApproval.isPresentedAsEnabled)
        XCTAssertFalse(LaunchAtLoginStatus.notRegistered.isPresentedAsEnabled)
        XCTAssertFalse(LaunchAtLoginStatus.notFound.isPresentedAsEnabled)
    }
}

extension CoreContractTests {
    func testLibraryCacheScopeSeparatesUsersAndNormalizesQueryWhitespace() {
        let first = LibraryCacheScope(userId: 7, view: "archive", query: "  AI  ", order: "desc", category: "Tech")
        let equivalent = LibraryCacheScope(userId: 7, view: "archive", query: "AI", order: "desc", category: "Tech")
        let otherUser = LibraryCacheScope(userId: 8, view: "archive", query: "AI", order: "desc", category: "Tech")

        XCTAssertEqual(first.key, equivalent.key)
        XCTAssertNotEqual(first.key, otherUser.key)
    }

    func testLibraryCacheCodecRoundTripsMetadataOnlyArticleList() throws {
        let article = ArticleCard(id: 9, title: "Cached", author: nil, source: "example.com", originalUrl: "https://example.com/a", publicId: nil, coverImage: nil, aiSummary: "summary", aiCategory: "AI", aiTags: ["Swift"], isFavorited: true, isArchived: false, isPublished: false)
        let response = ArticleListResponse(articles: [article], total: 1, page: 1, perPage: 20, totalPages: 1)

        let encoded = try LibraryCacheCodec.encode(response)
        let decoded = try LibraryCacheCodec.decode(encoded)
        XCTAssertEqual(decoded.articles, [article])
        XCTAssertEqual(decoded.totalPages, 1)
    }
}


extension CoreContractTests {
    @MainActor
    func testLibraryCacheStoreUpdatesOneScopeWithoutLeakingAcrossUsers() throws {
        let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: CachedArticleListRecord.self, configurations: configuration)
        let store = LibraryCacheStore(context: ModelContext(container))
        let user7 = LibraryCacheScope(userId: 7, view: "inbox", query: "", order: "desc", category: nil)
        let user8 = LibraryCacheScope(userId: 8, view: "inbox", query: "", order: "desc", category: nil)
        let first = ArticleListResponse(articles: [], total: 0, page: 1, perPage: 20, totalPages: 1)
        let updatedArticle = ArticleCard(id: 11, title: "User 7", author: nil, source: nil, originalUrl: nil, publicId: nil, coverImage: nil, aiSummary: nil, aiCategory: nil, aiTags: [], isFavorited: false, isArchived: false, isPublished: false)
        let updated = ArticleListResponse(articles: [updatedArticle], total: 1, page: 1, perPage: 20, totalPages: 1)

        try store.save(first, scope: user7)
        try store.save(updated, scope: user7)

        XCTAssertEqual(try store.load(scope: user7)?.articles.map(\.id), [11])
        XCTAssertNil(try store.load(scope: user8))
    }
}

extension CoreContractTests {
    @MainActor
    func testAccountChangeResetClearsEveryUserScopedPresentationValue() {
        let model = AppModel()
        model.user = NativeUser(id: 7, username: "alice", role: "user", status: "active")
        model.counts = ArticleCounts(inbox: 3, favorites: 2, archive: 1, published: 4)
        model.articles = [ArticleCard(id: 1, title: "Private", author: nil, source: nil, originalUrl: nil, publicId: nil, coverImage: nil, aiSummary: nil, aiCategory: nil, aiTags: [], isFavorited: false, isArchived: false, isPublished: false)]
        model.selectedArticle = model.articles.first
        model.jobs = [CollectJob(id: 1, url: "https://example.com", normalizedUrl: "https://example.com", status: "queued", stage: "queued", method: nil, captureStrategy: nil, articleId: nil, title: nil, errorSummary: nil, errorHint: nil)]
        model.archiveSources = [ArticleSource(source: "private.example", count: 1, latestCreatedAt: nil)]
        model.isOfflineCache = true

        model.resetUserScopedState()

        XCTAssertNil(model.user)
        XCTAssertEqual(model.counts, ArticleCounts(inbox: 0, favorites: 0, archive: 0, published: 0))
        XCTAssertTrue(model.articles.isEmpty)
        XCTAssertNil(model.selectedArticle)
        XCTAssertTrue(model.jobs.isEmpty)
        XCTAssertTrue(model.archiveSources.isEmpty)
        XCTAssertFalse(model.isOfflineCache)
    }
}

extension CoreContractTests {
    func testSelectedArticleForcesCompactListPresentationInMiddleColumn() {
        XCTAssertEqual(AppModel.PresentationMode.card.resolved(hasSelectedArticle: true), .list)
        XCTAssertEqual(AppModel.PresentationMode.grid.resolved(hasSelectedArticle: true), .list)
        XCTAssertEqual(AppModel.PresentationMode.card.resolved(hasSelectedArticle: false), .card)
    }

    func testReaderDocumentUsesExplicitDarkColorsInsteadOfAmbiguousSystemCanvasColors() {
        let html = ReaderDocumentBuilder.document(
            html: "<h2>Visible</h2><p>Body</p>",
            title: "Article",
            preferences: ReaderPreferences(textScale: 1, lineHeight: 1.8, horizontalPadding: 28),
            isDark: true
        )
        XCTAssertTrue(html.contains("background:#031f18"))
        XCTAssertTrue(html.contains("color:#f2eee3"))
        XCTAssertFalse(html.contains("CanvasText"))
    }
}

extension CoreContractTests {
    func testMenuBarTaskSummaryDistinguishesIdleAndActiveJobs() {
        XCTAssertEqual(MenuBarTaskSummary.title(activeCount: 0), "没有进行中的任务")
        XCTAssertEqual(MenuBarTaskSummary.title(activeCount: 3), "进行中任务：3")
    }
}

extension CoreContractTests {
    func testAppearancePreferenceMapsStoredValuesToSwiftUIColorSchemes() {
        XCTAssertNil(AppAppearance.system.colorScheme)
        XCTAssertEqual(AppAppearance.light.colorScheme, .light)
        XCTAssertEqual(AppAppearance.dark.colorScheme, .dark)
        XCTAssertEqual(AppAppearance(storedValue: "unknown"), .system)
    }
}

extension CoreContractTests {
    func testLibraryPresentationModesMatchDesktopAndAndroidSemantics() {
        XCTAssertEqual(AppModel.PresentationMode.list.rawValue, "列表")
        XCTAssertEqual(AppModel.PresentationMode.grid.rawValue, "瀑布流")
        XCTAssertEqual(AppModel.PresentationMode.card.rawValue, "卡片")
        XCTAssertEqual(LibraryCardLayout.waterfall.coverAspectRatio, 0.75, accuracy: 0.001)
        XCTAssertEqual(LibraryCardLayout.waterfall.titleLineLimit, 3)
        XCTAssertEqual(LibraryCardLayout.waterfall.summaryLineLimit, 0)
        XCTAssertEqual(LibraryCardLayout.waterfall.tagLimit, 1)
        XCTAssertEqual(LibraryCardLayout.waterfall.grid.maxColumns, 4)
        XCTAssertEqual(LibraryCardLayout.card.coverAspectRatio, 2.35, accuracy: 0.001)
        XCTAssertEqual(LibraryCardLayout.card.grid.maxColumns, 3)
        XCTAssertEqual(LibraryCardLayout.card.titleLineLimit, 2)
        XCTAssertEqual(LibraryCardLayout.card.summaryLineLimit, 2)
    }

    func testAdaptiveGridCapsCardWidthAndAddsColumnsInsteadOfStretching() {
        let waterfall = LibraryCardLayout.waterfall.grid.frame(for: 1_280)
        XCTAssertEqual(waterfall.columnCount, 4)
        XCTAssertEqual(waterfall.itemWidth, 300, accuracy: 0.001)
        XCTAssertEqual(waterfall.contentWidth, 1_248, accuracy: 0.001)

        let card = LibraryCardLayout.card.grid.frame(for: 1_600)
        XCTAssertEqual(card.columnCount, 3)
        XCTAssertEqual(card.itemWidth, 520, accuracy: 0.001)
        XCTAssertEqual(card.contentWidth, 1_592, accuracy: 0.001)
    }

    func testAdaptiveGridUsesSmallerColumnCountsAsSpaceNarrows() {
        let waterfall = LibraryCardLayout.waterfall.grid.frame(for: 600)
        XCTAssertEqual(waterfall.columnCount, 2)
        XCTAssertEqual(waterfall.itemWidth, 292, accuracy: 0.001)

        let narrowCard = LibraryCardLayout.card.grid.frame(for: 320)
        XCTAssertEqual(narrowCard.columnCount, 1)
        XCTAssertEqual(narrowCard.itemWidth, 320, accuracy: 0.001)
    }

    func testListLayoutKeepsWideLeftThumbnailAndWaterfallUsesConfiguredColumnLimit() {
        XCTAssertEqual(LibraryCardLayout.list.thumbnailWidth, 116)
        XCTAssertEqual(LibraryCardLayout.list.thumbnailHeight, 76)
        XCTAssertEqual(LibraryCardLayout.waterfall.grid.maxColumns, 4)
        XCTAssertEqual(LibraryCardLayout.card.grid.maxColumns, 3)
    }
}
