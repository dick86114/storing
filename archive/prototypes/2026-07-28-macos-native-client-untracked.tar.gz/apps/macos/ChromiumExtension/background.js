chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !/^https?:\/\//i.test(tab.url)) return;
  const params = new URLSearchParams({ url: tab.url, title: tab.title || "", source: "browser" });
  await chrome.tabs.update(tab.id, { url: `qiankunjie://collect?${params.toString()}` });
});
