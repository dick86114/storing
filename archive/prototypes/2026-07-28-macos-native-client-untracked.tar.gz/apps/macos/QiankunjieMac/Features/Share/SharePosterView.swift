import AppKit
import CoreImage.CIFilterBuiltins
import SwiftUI
import UniformTypeIdentifiers

struct SharePosterSheet: View {
    @Environment(\.dismiss) private var dismiss
    let article: ArticleDetail
    @State private var rendered: NSImage?
    var body: some View {
        VStack(spacing: 14) {
            HStack { Text("分享海报").font(.title2).fontWeight(.semibold); Spacer(); Button("关闭") { dismiss() } }.padding(.horizontal)
            Group { if let rendered { Image(nsImage: rendered).resizable().scaledToFit() } else { ProgressView("正在生成海报…") } }
                .frame(width: 430, height: 570).background(.black.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
            HStack { Button("保存图片") { save() }; Button("分享海报") { share() }.buttonStyle(.borderedProminent) }.padding(.bottom)
        }.padding(.top).task { rendered = render() }
    }
    @MainActor private func render() -> NSImage? {
        let renderer = ImageRenderer(content: PosterCanvas(article: article).frame(width: 720, height: 960))
        renderer.scale = 2
        return renderer.nsImage
    }
    private func save() { guard let image = rendered, let data = image.pngData else { return }; let panel = NSSavePanel(); panel.allowedContentTypes = [.png]; panel.nameFieldStringValue = "qiankunjie-\(article.id).png"; if panel.runModal() == .OK, let url = panel.url { try? data.write(to: url, options: .atomic) } }
    private func share() { guard let image = rendered, let data = image.pngData else { return }; let url = FileManager.default.temporaryDirectory.appending(path: "qiankunjie-share-\(article.id).png"); try? data.write(to: url, options: .atomic); NSSharingServicePicker(items: [url, article.displayTitle]).show(relativeTo: .zero, of: NSApp.keyWindow?.contentView ?? NSView(), preferredEdge: .minY) }
}

private struct PosterCanvas: View {
    let article: ArticleDetail
    var shareURL: URL? { article.publicId.flatMap { URL(string: "https://storing.idickies.com/p/\($0)") } ?? article.originalUrl.flatMap(URL.init(string:)) }
    var body: some View {
        ZStack {
            LinearGradient(colors: [QKColor.ink, QKColor.bamboo, Color(hex: 0x183D2D)], startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle().fill(QKColor.gold.opacity(0.10)).frame(width: 520).blur(radius: 2).offset(x: 250, y: -360)
            VStack(alignment: .leading, spacing: 26) {
                HStack { Image("BrandLogo").resizable().scaledToFit().frame(width: 68, height: 68).clipShape(RoundedRectangle(cornerRadius: 15)); VStack(alignment: .leading) { Text("乾坤戒").font(.system(size: 30, weight: .bold, design: .serif)); Text("STORING · 稍后阅读").font(.system(size: 14)).tracking(2).foregroundStyle(QKColor.gold) }; Spacer(); Image(systemName: "sparkles").font(.system(size: 28)).foregroundStyle(QKColor.gold) }
                Spacer()
                Text(article.displayTitle).font(.system(size: 44, weight: .bold, design: .serif)).lineSpacing(8).foregroundStyle(.white)
                if let summary = article.aiSummary { Text(summary).font(.system(size: 22)).lineSpacing(8).foregroundStyle(.white.opacity(0.78)).lineLimit(7) }
                HStack { ForEach(article.aiTags.prefix(4), id: \.self) { Text($0).font(.system(size: 15, weight: .semibold)).padding(.horizontal, 12).padding(.vertical, 7).background(QKColor.gold.opacity(0.18), in: Capsule()).foregroundStyle(QKColor.gold) } }
                Spacer()
                HStack(alignment: .bottom) { VStack(alignment: .leading, spacing: 7) { Text(article.source ?? "未知来源").font(.system(size: 18, weight: .semibold)); Text("扫码阅读全文").font(.system(size: 15)).foregroundStyle(.white.opacity(0.65)) }; Spacer(); if let shareURL, let qr = QRCode.image(for: shareURL.absoluteString) { Image(nsImage: qr).interpolation(.none).resizable().frame(width: 130, height: 130).padding(10).background(.white, in: RoundedRectangle(cornerRadius: 12)) } }
            }.padding(54).foregroundStyle(.white)
        }.clipShape(RoundedRectangle(cornerRadius: 28))
    }
}

enum QRCode {
    static func image(for value: String) -> NSImage? { let filter = CIFilter.qrCodeGenerator(); filter.message = Data(value.utf8); filter.correctionLevel = "M"; guard let output = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 8, y: 8)) else { return nil }; let rep = NSCIImageRep(ciImage: output); let image = NSImage(size: rep.size); image.addRepresentation(rep); return image }
}

private extension NSImage {
    var pngData: Data? { guard let tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiffRepresentation) else { return nil }; return bitmap.representation(using: .png, properties: [:]) }
}
