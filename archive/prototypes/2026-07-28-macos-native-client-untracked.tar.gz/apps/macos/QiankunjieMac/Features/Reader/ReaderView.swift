import AppKit
import SwiftUI
import WebKit

struct ReaderView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.colorScheme) private var colorScheme
    let article: ArticleDetail
    let offlineFile: URL?
    let focused: Bool
    @AppStorage("reader.textScale") private var textScale = 1.0
    @AppStorage("reader.lineHeight") private var lineHeight = 1.8
    @AppStorage("reader.padding") private var readerPadding = 28.0
    @State private var confirmAction: ReaderConfirmation?
    @State private var showSharePoster = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                if !focused { Button { model.selectedArticle = nil; model.articleDetail = nil } label: { Image(systemName: "chevron.left") }.help("返回文章列表") }
                Text(article.displayTitle).font(.headline).lineLimit(1)
                Spacer()
                if model.user != nil {
                    Button { Task { await model.performArticleAction("favorite") } } label: { Image(systemName: article.isFavorited ? "heart.fill" : "heart") }.help(article.isFavorited ? "取消收藏" : "收藏")
                    Button { confirmAction = .archive } label: { Image(systemName: article.isArchived ? "tray.and.arrow.down.fill" : "archivebox") }.help(article.isArchived ? "移回收件箱" : "归档")
                    Button { confirmAction = .publish } label: { Image(systemName: article.isPublished ? "globe.badge.chevron.backward" : "globe") }.help(article.isPublished ? "取消发布" : "发布")
                }
                if let raw = article.originalUrl, let url = URL(string: raw) {
                    ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }.help("分享原网页")
                    Button { NSWorkspace.shared.open(url) } label: { Image(systemName: "safari") }.help("打开原网页")
                }
                Menu {
                    Button("重新抓取") { confirmAction = .refetch }
                    Button("重新生成 AI 摘要") { confirmAction = .regenerate }
                    Divider()
                    Button(model.isDownloadingOffline ? "正在下载…" : "下载离线内容") { Task { await model.downloadCurrentArticle() } }.disabled(model.isDownloadingOffline)
                    Button("分享海报") { if article.isPublished { showSharePoster = true } else { confirmAction = .sharePoster } }
                    Divider()
                    Button("从资料库删除", role: .destructive) { confirmAction = .delete }
                    if model.isAdmin { Button("永久删除", role: .destructive) { confirmAction = .permanentDelete } }
                } label: { Image(systemName: "ellipsis") }
                Button { model.focusReading.toggle() } label: { Image(systemName: focused ? "rectangle.split.3x1" : "arrow.up.left.and.arrow.down.right") }.help("专注阅读")
            }.padding(12).background(.bar)
            Divider()

            if let html = article.contentHtml, !html.isEmpty {
                SafeArticleWebView(
                    html: html,
                    title: article.displayTitle,
                    baseURL: offlineFile?.deletingLastPathComponent() ?? APIEndpoint.baseURL,
                    preferences: ReaderPreferences(textScale: textScale, lineHeight: lineHeight, horizontalPadding: readerPadding),
                    isDark: colorScheme == .dark
                )
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        readerHeader
                        if let summary = article.aiSummary {
                            VStack(alignment: .leading, spacing: 8) { Label("AI 摘要", systemImage: "sparkles").font(.headline).foregroundStyle(QKColor.gold); Text(summary).font(.body).lineSpacing(7) }
                                .padding(18).background(QKColor.gold.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                        }
                        Text(article.contentMd?.nilIfEmpty ?? "正文暂时不可用").font(.body).lineSpacing(8).textSelection(.enabled)
                    }.frame(maxWidth: 820, alignment: .leading).padding(.horizontal, 42).padding(.vertical, 36).frame(maxWidth: .infinity)
                }
            }
        }
        .confirmationDialog(confirmAction?.title ?? "确认操作", isPresented: Binding(get: { confirmAction != nil }, set: { if !$0 { confirmAction = nil } })) {
            if let action = confirmAction {
                Button(action.buttonTitle, role: action.destructive ? .destructive : nil) {
                    confirmAction = nil
                    Task {
                        if action == .delete || action == .permanentDelete {
                            await model.deleteCurrentArticle(permanently: action == .permanentDelete)
                        } else {
                            await model.performArticleAction(action.apiAction)
                            if action == .sharePoster, model.articleDetail?.isPublished == true { showSharePoster = true }
                        }
                    }
                }
            }
            Button("取消", role: .cancel) { confirmAction = nil }
        } message: { Text(confirmAction?.message(article: article) ?? "") }
        .sheet(isPresented: $showSharePoster) { SharePosterSheet(article: model.articleDetail ?? article) }
    }

    private var readerHeader: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(article.displayTitle).font(.system(size: 30, weight: .bold, design: .serif)).textSelection(.enabled)
            HStack { if let author = article.author { Label(author, systemImage: "person") }; if let source = article.source { Label(source, systemImage: "globe") }; if let date = article.publishTime { Label(String(date.prefix(10)), systemImage: "calendar") } }.font(.caption).foregroundStyle(.secondary)
            HStack { ForEach(article.aiTags, id: \.self) { Text($0).font(.caption).padding(.horizontal, 8).padding(.vertical, 4).background(QKColor.gold.opacity(0.15), in: Capsule()) } }
        }
    }
}

private enum ReaderConfirmation {
    case archive, publish, refetch, regenerate, sharePoster, delete, permanentDelete
    var title: String { switch self { case .archive: "确认调整归档状态？"; case .publish: "确认调整发布状态？"; case .refetch: "重新抓取文章？"; case .regenerate: "重新生成 AI 摘要？"; case .sharePoster: "发布并生成分享海报？"; case .delete: "从资料库删除？"; case .permanentDelete: "永久删除这篇文章？" } }
    var buttonTitle: String { switch self { case .archive: "确认"; case .publish: "确认发布变更"; case .refetch: "重新抓取"; case .regenerate: "重新生成"; case .sharePoster: "发布并生成海报"; case .delete: "确认删除"; case .permanentDelete: "永久删除" } }
    var apiAction: String { switch self { case .archive: "archive"; case .publish: "publish"; case .refetch: "refetch"; case .regenerate: "regenerate-ai"; case .sharePoster: "publish"; case .delete, .permanentDelete: "" } }
    var destructive: Bool { self == .refetch || self == .delete || self == .permanentDelete }
    func message(article: ArticleDetail) -> String {
        switch self {
        case .archive: article.isArchived ? "文章将移回收件箱。" : "文章将进入归档，收藏和发布状态不变。"
        case .publish: article.isPublished ? "公开链接将停止展示，个人资料库内容保留。" : "发布后任何持有公开链接的人都可阅读；必要时服务端会先归档并补齐 AI 信息。"
        case .refetch: "将覆盖当前保存的正文和封面，收藏、归档和发布状态不变。"
        case .regenerate: "不会重新抓取原文，将基于当前正文生成摘要、分类和标签。"
        case .sharePoster: "分享私有文章会先公开发布。发布完成后将生成带公开链接二维码的海报。"
        case .delete: "只移除当前用户的资料库记录，不影响原网页。"
        case .permanentDelete: "将彻底清除文章正文和元数据，无法恢复。"
        }
    }
}

struct SafeArticleWebView: NSViewRepresentable {
    let html: String
    let title: String
    let baseURL: URL
    let preferences: ReaderPreferences
    let isDark: Bool
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = false
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        return webView
    }
    func updateNSView(_ webView: WKWebView, context: Context) {
        let signature = html + preferences.css + baseURL.absoluteString + String(isDark)
        guard context.coordinator.lastHTML != signature else { return }
        context.coordinator.lastHTML = signature
        let document = ReaderDocumentBuilder.document(
            html: html,
            title: title,
            preferences: preferences,
            isDark: isDark
        )
        webView.loadHTMLString(document, baseURL: baseURL)
    }
    final class Coordinator: NSObject, WKNavigationDelegate {
        var lastHTML: String?
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping @MainActor (WKNavigationActionPolicy) -> Void) {
            if navigationAction.navigationType == .linkActivated, let url = navigationAction.request.url {
                NSWorkspace.shared.open(url); decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }
    }
}


enum ReaderDocumentBuilder {
    static func document(html: String, title: String, preferences: ReaderPreferences, isDark: Bool) -> String {
        let background = isDark ? "#031f18" : "#fbf8ef"
        let foreground = isDark ? "#f2eee3" : "#20241f"
        let muted = isDark ? "#a8b4aa" : "#687068"
        return """
        <!doctype html><html><head><meta name="viewport" content="width=device-width"><style>
        :root{color-scheme:\(isDark ? "dark" : "light")}html,body{min-height:100%;background:\(background);color:\(foreground)}body{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;\(preferences.css);max-width:860px;margin:0 auto}h1,h2,h3{font-family:'Songti SC','STSong',serif;color:#c9a84c;line-height:1.35}img{max-width:100%;height:auto;border-radius:10px}pre{overflow:auto;padding:16px;border-radius:10px;background:rgba(127,127,127,.12)}a{color:#c9a84c}blockquote{border-left:3px solid #c9a84c;margin-left:0;padding-left:18px;color:\(muted)}
        </style><title>\(escape(title))</title></head><body>\(html)</body></html>
        """
    }

    private static func escape(_ value: String) -> String {
        value
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }
}
