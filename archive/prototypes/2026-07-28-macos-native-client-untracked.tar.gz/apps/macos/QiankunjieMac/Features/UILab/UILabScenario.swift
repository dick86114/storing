import Foundation

enum UILabScenario: String, CaseIterable, Equatable, Sendable {
    case library, waterfall, card, reader, empty, loading, offline, login

    init(arguments: [String]) {
        let raw = arguments.first(where: { $0.hasPrefix("--ui-lab-scenario=") })?.split(separator: "=", maxSplits: 1).last.map(String.init)
        self = raw.flatMap(Self.init(rawValue:)) ?? .library
    }
}

extension AppModel {
    func configureUILab(arguments: [String]) {
        let scenario = UILabScenario(arguments: arguments)
        user = NativeUser(id: 1, username: "林小北", role: "admin", status: "active")
        destination = .inbox
        counts = ArticleCounts(inbox: 36, favorites: 12, archive: 89, published: 5)
        let fixtures = Self.uiLabArticles
        articles = scenario == .empty || scenario == .loading ? [] : fixtures
        isLoading = scenario == .loading
        isOfflineCache = scenario == .offline
        showsLogin = scenario == .login
        switch scenario {
        case .library:
            presentationMode = .list
        case .waterfall:
            presentationMode = .grid
        case .card:
            presentationMode = .card
        default:
            presentationMode = .card
        }
        if scenario == .reader, let first = fixtures.first {
            selectedArticle = first
            articleDetail = Self.uiLabDetail
        }
    }

    private static var uiLabArticles: [ArticleCard] {
        [
            ArticleCard(id: 9001, title: "大模型应用开发的 9 个坑：从 RAG 到 Agent", author: "林小北", source: "sspai.com", originalUrl: "https://example.com/ai", publicId: "ui-lab", coverImage: nil, aiSummary: "系统梳理 RAG 检索、Agent 循环和 Prompt 注入等工程问题。", aiCategory: "AI 工程化", aiTags: ["RAG", "Agent", "安全"], isFavorited: true, isArchived: false, isPublished: true),
            ArticleCard(id: 9002, title: "为什么我从 Next.js 迁移到了 Remix", author: nil, source: "微信公众号", originalUrl: "https://example.com/web", publicId: nil, coverImage: nil, aiSummary: "从数据获取、部署和生态比较两种前端框架。", aiCategory: "前端", aiTags: ["Next.js", "Remix"], isFavorited: false, isArchived: true, isPublished: false),
            ArticleCard(id: 9003, title: "PostgreSQL 性能调优手册", author: "Database Team", source: "github.blog", originalUrl: "https://example.com/db", publicId: nil, coverImage: nil, aiSummary: "索引选型、查询计划与分区表实践。", aiCategory: "数据库", aiTags: ["PostgreSQL", "性能"], isFavorited: false, isArchived: false, isPublished: false),
            ArticleCard(id: 9004, title: "如何建立真正可执行的个人知识库", author: "张晓", source: "少数派", originalUrl: "https://example.com/knowledge", publicId: nil, coverImage: nil, aiSummary: "从收集、整理到定期回顾的一套个人知识管理工作流。", aiCategory: "效率", aiTags: ["知识管理", "工作流"], isFavorited: true, isArchived: false, isPublished: false),
            ArticleCard(id: 9005, title: "设计系统不只是组件库", author: "Design Team", source: "Figma Blog", originalUrl: "https://example.com/design-system", publicId: nil, coverImage: nil, aiSummary: "用设计令牌、协作流程和治理机制让系统持续生长。", aiCategory: "设计", aiTags: ["设计系统", "Figma"], isFavorited: false, isArchived: false, isPublished: true),
            ArticleCard(id: 9006, title: "关于远程工作和深度专注的十个发现", author: "陈白", source: "Medium", originalUrl: "https://example.com/focus", publicId: nil, coverImage: nil, aiSummary: "远程协作环境中建立边界、安排深度工作的实用方法。", aiCategory: "职场", aiTags: ["远程工作", "专注"], isFavorited: false, isArchived: true, isPublished: false),
            ArticleCard(id: 9007, title: "SwiftUI 性能优化：避免不必要的视图重绘", author: "Apple Developer", source: "developer.apple.com", originalUrl: "https://example.com/swiftui", publicId: nil, coverImage: nil, aiSummary: "从状态粒度、数据流和列表渲染理解 SwiftUI 性能。", aiCategory: "开发", aiTags: ["SwiftUI", "性能"], isFavorited: true, isArchived: false, isPublished: false),
            ArticleCard(id: 9008, title: "从零搭建可观测的任务系统", author: "Ops Team", source: "InfoQ", originalUrl: "https://example.com/observability", publicId: nil, coverImage: nil, aiSummary: "为异步任务设计状态机、重试、告警和可追踪的运行记录。", aiCategory: "工程", aiTags: ["可观测性", "任务"], isFavorited: false, isArchived: false, isPublished: false),
            ArticleCard(id: 9009, title: "给独立开发者的产品定价笔记", author: "周林", source: "即刻", originalUrl: "https://example.com/pricing", publicId: nil, coverImage: nil, aiSummary: "从价值锚点、用户分层到小规模实验寻找合适的产品价格。", aiCategory: "产品", aiTags: ["定价", "独立开发"], isFavorited: false, isArchived: false, isPublished: true),
            ArticleCard(id: 9010, title: "图像生成工作流的版权与归属边界", author: "李然", source: "极客公园", originalUrl: "https://example.com/copyright", publicId: nil, coverImage: nil, aiSummary: "梳理素材授权、模型输出和商用发布中的常见风险。", aiCategory: "AI", aiTags: ["版权", "图像生成"], isFavorited: false, isArchived: true, isPublished: false),
        ]
    }

    private static var uiLabDetail: ArticleDetail {
        ArticleDetail(id: 9001, title: "大模型应用开发的 9 个坑：从 RAG 到 Agent", author: "林小北", source: "sspai.com", originalUrl: "https://example.com/ai", publicId: "ui-lab", coverImage: nil, publishTime: "2026-07-27T12:00:00Z", createdAt: "2026-07-27T12:00:00Z", aiSummary: "系统梳理大模型应用开发中常见的工程陷阱，并给出可执行的防护策略。", aiCategory: "AI 工程化", aiTags: ["RAG", "Agent", "Prompt 安全"], isFavorited: true, isArchived: false, isPublished: true, contentHtml: "<h2>一、RAG 检索质量的隐形退化</h2><p>检索系统需要持续监控召回率和内容时效性。</p><h2>二、Agent 的无限循环问题</h2><p>工具调用必须设置预算、超时和明确的终止条件。</p>", contentMd: nil)
    }
}
