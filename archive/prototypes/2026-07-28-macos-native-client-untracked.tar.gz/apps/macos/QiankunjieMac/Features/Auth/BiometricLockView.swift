import LocalAuthentication
import SwiftUI

struct BiometricLockView: View {
    @Environment(AppModel.self) private var model
    @State private var message = "请通过 Touch ID 验证以继续使用"
    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
            VStack(spacing: 18) {
                Image("BrandLogo").resizable().scaledToFit().frame(width: 86, height: 86).clipShape(RoundedRectangle(cornerRadius: 20)).shadow(color: QKColor.gold.opacity(0.4), radius: 16)
                Text("乾坤戒已锁定").font(.title).fontWeight(.semibold).fontDesign(.serif)
                Text(message).foregroundStyle(.secondary)
                Button("使用 Touch ID 解锁") { authenticate() }.buttonStyle(.borderedProminent)
            }.padding(36).qkCard()
        }.onAppear { authenticate() }
    }
    private func authenticate() {
        let context = LAContext()
        context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "解锁乾坤戒") { success, error in
            Task { @MainActor in if success { withAnimation(.smooth) { model.isLocked = false } } else { message = error?.localizedDescription ?? "验证失败，请重试" } }
        }
    }
}
