import SwiftUI

struct LoginView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var username = ""
    @State private var password = ""
    @State private var showPassword = false

    var body: some View {
        VStack(spacing: 22) {
            Image("BrandLogo")
                .resizable().scaledToFit().frame(width: 76, height: 76)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .shadow(color: QKColor.gold.opacity(0.35), radius: 14, y: 5)
                .transition(.scale.combined(with: .opacity))
            VStack(spacing: 5) {
                Text("登录乾坤戒").font(.title2).fontWeight(.semibold).fontDesign(.serif)
                Text("访问你的个人资料库与采集任务").foregroundStyle(.secondary)
            }
            TextField("用户名", text: $username).textFieldStyle(.roundedBorder)
            HStack {
                Group { if showPassword { TextField("密码", text: $password) } else { SecureField("密码", text: $password) } }
                Button { showPassword.toggle() } label: { Image(systemName: showPassword ? "eye.slash" : "eye") }.buttonStyle(.plain)
            }.padding(7).background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 7))
            if let error = model.errorMessage {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
            HStack {
                Button("取消") { model.errorMessage = nil; dismiss() }
                Spacer()
                if model.isLoading { ProgressView().controlSize(.small) }
                Button("登录") { Task { _ = await model.login(username: username, password: password) } }
                    .buttonStyle(.borderedProminent).disabled(username.isEmpty || password.isEmpty || model.isLoading)
            }
            .animation(.snappy, value: model.isLoading)
        }
        .padding(32).frame(width: 390)
        .animation(.snappy, value: model.errorMessage)
    }
}
