import SwiftUI

struct LibraryView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var model = model
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(model.destination.title).font(.title2).fontWeight(.semibold).fontDesign(.serif)
                    Text("\(model.articles.count) 篇文章").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Picker("排序", selection: $model.sortOrder) { Text("最新在前").tag("desc"); Text("最早在前").tag("asc") }.frame(width: 120)
                if model.destination == .archive {
                    Picker("来源", selection: $model.selectedCategory) {
                        Text("全部来源").tag(String?.none)
                        ForEach(model.archiveSources) { item in Text("\(item.source) (\(item.count))").tag(Optional(item.source)) }
                    }.frame(width: 170)
                }
                Picker("视图", selection: $model.presentationMode) { ForEach(AppModel.PresentationMode.allCases, id: \.self) { Text($0.rawValue).tag($0) } }.pickerStyle(.segmented).frame(width: 180)
                Button { model.showsCollect = true } label: { Image(systemName: "plus") }.help("快速采集")
                Button { Task { await model.reload() } } label: { Image(systemName: "arrow.clockwise") }.help("刷新")
            }.padding(18)
            Divider()
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("搜索标题、来源、摘要或标签…", text: $model.searchQuery)
                    .textFieldStyle(.plain).onSubmit { Task { await model.reload() } }
                if !model.searchQuery.isEmpty { Button { model.searchQuery = ""; Task { await model.reload() } } label: { Image(systemName: "xmark.circle.fill") }.buttonStyle(.plain) }
            }.padding(10).background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 9)).padding(.horizontal, 18).padding(.vertical, 10)

            if model.isOfflineCache {
                Label("当前显示离线缓存内容", systemImage: "wifi.slash")
                    .font(.caption).foregroundStyle(.orange)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 18).padding(.bottom, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
            if model.isLoading && model.articles.isEmpty {
                ProgressView("正在加载资料库…").frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if model.articles.isEmpty {
                ContentUnavailableView("暂无文章", systemImage: "tray", description: Text(model.destination == .published ? "还没有公开发布的文章" : "采集内容后会显示在这里"))
            } else {
                articleContent
            }
        }
        .background(.background)
        .onChange(of: model.sortOrder) { _, _ in Task { await model.reload() } }
        .onChange(of: model.selectedCategory) { _, _ in if model.destination == .archive { Task { await model.reload() } } }
    }

    private var loadMoreButton: some View {
        Button { Task { await model.loadMore() } } label: {
            if model.isLoadingMore { ProgressView().controlSize(.small) } else { Label("加载更多", systemImage: "arrow.down.circle") }
        }
        .buttonStyle(.borderless)
        .frame(maxWidth: .infinity)
        .padding(10)
        .disabled(model.isLoadingMore)
    }

    @ViewBuilder private var articleContent: some View {
        switch model.presentationMode.resolved(hasSelectedArticle: model.selectedArticle != nil) {
        case .grid:
            AdaptiveArticleGrid(layout: LibraryCardLayout.waterfall.grid) { columns in
                ForEach(model.articles) { article in
                    WaterfallArticleCard(article: article)
                }
                if model.pagination.hasMore { loadMoreButton.gridCellColumns(columns) }
            }
        case .list:
            ScrollView {
                LazyVStack(spacing: 11) {
                    ForEach(model.articles) { article in
                        ArticleListRow(article: article, compact: model.selectedArticle != nil)
                    }
                    if model.pagination.hasMore { loadMoreButton }
                }
                .padding(18)
            }
        case .card:
            AdaptiveArticleGrid(layout: LibraryCardLayout.card.grid) { columns in
                ForEach(model.articles) { article in
                    StandardArticleCard(article: article)
                }
                if model.pagination.hasMore { loadMoreButton.gridCellColumns(columns) }
            }
        }
    }
}

private struct AdaptiveArticleGrid<Content: View>: View {
    let layout: AdaptiveGridLayout
    private let content: (Int) -> Content

    init(layout: AdaptiveGridLayout, @ViewBuilder content: @escaping (Int) -> Content) {
        self.layout = layout
        self.content = content
    }

    var body: some View {
        GeometryReader { geometry in
            let frame = layout.frame(for: max(0, Double(geometry.size.width) - 36))
            let columns = Array(
                repeating: GridItem(.fixed(CGFloat(frame.itemWidth)), spacing: CGFloat(layout.spacing)),
                count: frame.columnCount
            )
            ScrollView {
                LazyVGrid(columns: columns, alignment: .leading, spacing: CGFloat(layout.spacing)) {
                    content(frame.columnCount)
                }
                .frame(width: CGFloat(frame.contentWidth), alignment: .leading)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.vertical, 18)
            }
        }
    }
}

private struct ArticleCover: View {
    let article: ArticleCard
    let aspectRatio: CGFloat

    private var palette: [Color] {
        switch article.id % 4 {
        case 0: [QKColor.bambooRaised, QKColor.gold.opacity(0.72)]
        case 1: [Color(hex: 0x354A3D), Color(hex: 0x86733C)]
        case 2: [Color(hex: 0x17384A), Color(hex: 0x6D5B95)]
        default: [Color(hex: 0x4A3029), Color(hex: 0xA67A42)]
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: palette, startPoint: .topLeading, endPoint: .bottomTrailing)
            Image(systemName: "book.closed.fill")
                .font(.system(size: 28, weight: .medium))
                .foregroundStyle(.white.opacity(0.85))
            if let raw = article.coverImage, let url = URL(string: raw) {
                AsyncImage(url: url) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    ProgressView().controlSize(.small).tint(.white)
                }
            }
            if article.isPublished {
                Image(systemName: "globe")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(QKColor.gold)
                    .padding(7)
                    .background(.black.opacity(0.48), in: Circle())
                    .padding(8)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
            }
        }
        .aspectRatio(aspectRatio, contentMode: .fit)
        .clipped()
        .accessibilityLabel("\(article.displayTitle) 的封面")
    }
}

private struct ArticleMetaLine: View {
    let article: ArticleCard

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "globe")
            Text(article.source ?? "未知来源")
                .lineLimit(1)
            Spacer(minLength: 0)
            if article.isFavorited { Image(systemName: "heart.fill").foregroundStyle(.pink) }
            if article.isArchived { Image(systemName: "archivebox.fill").foregroundStyle(.secondary) }
            if article.isPublished { Image(systemName: "globe.asia.australia.fill").foregroundStyle(QKColor.gold) }
        }
        .font(.caption)
        .foregroundStyle(.secondary)
    }
}

private struct ArticleTags: View {
    let tags: [String]
    let limit: Int

    var body: some View {
        if !tags.isEmpty, limit > 0 {
            HStack(spacing: 6) {
                ForEach(Array(tags.prefix(limit)), id: \.self) { tag in
                    Text(tag)
                        .font(.caption2)
                        .lineLimit(1)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(QKColor.gold.opacity(0.15), in: Capsule())
                }
                if tags.count > limit {
                    Text("+\(tags.count - limit)").font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
    }
}

private struct ArticleInteractionModifier: ViewModifier {
    @Environment(AppModel.self) private var model
    @State private var hovering = false
    let article: ArticleCard

    func body(content: Content) -> some View {
        content
            .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .scaleEffect(hovering ? 1.008 : 1)
            .offset(y: hovering ? -2 : 0)
            .shadow(color: QKColor.gold.opacity(hovering ? 0.12 : 0), radius: 10, y: 4)
            .onHover { hovering = $0 }
            .animation(.snappy(duration: 0.22), value: hovering)
            .onTapGesture { Task { await model.open(article) } }
            .onTapGesture(count: 2) { Task { await model.open(article) } }
            .contextMenu {
                Button("打开文章") { Task { await model.open(article) } }
                if let raw = article.originalUrl, let url = URL(string: raw) {
                    Button("在浏览器中打开") { NSWorkspace.shared.open(url) }
                }
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel(article.displayTitle)
    }
}

private extension View {
    func articleInteraction(_ article: ArticleCard) -> some View {
        modifier(ArticleInteractionModifier(article: article))
    }
}

struct WaterfallArticleCard: View {
    let article: ArticleCard
    private let layout = LibraryCardLayout.waterfall

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ArticleCover(article: article, aspectRatio: layout.coverAspectRatio)
            VStack(alignment: .leading, spacing: 8) {
                ArticleMetaLine(article: article)
                Text(article.displayTitle)
                    .font(.headline)
                    .fontDesign(.serif)
                    .lineLimit(layout.titleLineLimit)
                ArticleTags(tags: article.aiTags, limit: layout.tagLimit)
            }
            .padding(12)
        }
        .qkCard()
        .articleInteraction(article)
    }
}

struct StandardArticleCard: View {
    let article: ArticleCard
    private let layout = LibraryCardLayout.card

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ArticleCover(article: article, aspectRatio: layout.coverAspectRatio)
            VStack(alignment: .leading, spacing: 10) {
                ArticleMetaLine(article: article)
                Text(article.displayTitle)
                    .font(.title3.weight(.semibold))
                    .fontDesign(.serif)
                    .lineLimit(layout.titleLineLimit)
                if let summary = article.aiSummary?.nilIfEmpty {
                    Text(summary)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(layout.summaryLineLimit)
                }
                ArticleTags(tags: article.aiTags, limit: layout.tagLimit)
            }
            .padding(16)
        }
        .qkCard()
        .articleInteraction(article)
    }
}

struct ArticleListRow: View {
    let article: ArticleCard
    let compact: Bool
    private let layout = LibraryCardLayout.list

    var body: some View {
        HStack(alignment: .top, spacing: compact ? 10 : 14) {
            ArticleCover(article: article, aspectRatio: layout.coverAspectRatio)
                .frame(width: compact ? 82 : CGFloat(layout.thumbnailWidth))
            VStack(alignment: .leading, spacing: compact ? 5 : 7) {
                ArticleMetaLine(article: article)
                Text(article.displayTitle)
                    .font(compact ? .subheadline.weight(.semibold) : .headline)
                    .fontDesign(.serif)
                    .lineLimit(layout.titleLineLimit)
                if let summary = article.aiSummary?.nilIfEmpty {
                    Text(summary)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(compact ? 1 : layout.summaryLineLimit)
                }
                if !compact { ArticleTags(tags: article.aiTags, limit: layout.tagLimit) }
            }
        }
        .padding(compact ? 10 : 13)
        .qkCard()
        .articleInteraction(article)
    }
}
