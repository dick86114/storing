import Foundation

struct LibraryPagination: Equatable, Sendable {
    private(set) var page: Int
    private(set) var totalPages: Int
    init(page: Int = 1, totalPages: Int = 1) { self.page = max(1, page); self.totalPages = max(1, totalPages) }
    mutating func nextPage() -> Int? { guard page < totalPages else { return nil }; page += 1; return page }
    mutating func reset(totalPages: Int) { page = 1; self.totalPages = max(1, totalPages) }
    var hasMore: Bool { page < totalPages }
}

extension AppModel.PresentationMode {
    func resolved(hasSelectedArticle: Bool) -> Self {
        hasSelectedArticle ? .list : self
    }
}


struct AdaptiveGridFrame: Equatable, Sendable {
    let columnCount: Int
    let itemWidth: Double
    let contentWidth: Double
}

struct AdaptiveGridLayout: Equatable, Sendable {
    let minItemWidth: Double
    let maxItemWidth: Double
    let spacing: Double
    let maxColumns: Int

    init(minItemWidth: Double, maxItemWidth: Double, spacing: Double = 16, maxColumns: Int) {
        self.minItemWidth = minItemWidth
        self.maxItemWidth = maxItemWidth
        self.spacing = spacing
        self.maxColumns = max(1, maxColumns)
    }

    func frame(for availableWidth: Double) -> AdaptiveGridFrame {
        let width = max(0, availableWidth)
        let fittingColumns = Int((width + spacing) / (minItemWidth + spacing))
        let columnCount = min(maxColumns, max(1, fittingColumns))
        let naturalItemWidth = max(0, (width - spacing * Double(columnCount - 1)) / Double(columnCount))
        let itemWidth = min(maxItemWidth, naturalItemWidth)
        let contentWidth = itemWidth * Double(columnCount) + spacing * Double(columnCount - 1)
        return AdaptiveGridFrame(columnCount: columnCount, itemWidth: itemWidth, contentWidth: contentWidth)
    }
}

struct LibraryCardLayout: Equatable, Sendable {
    let coverAspectRatio: Double
    let titleLineLimit: Int
    let summaryLineLimit: Int
    let tagLimit: Int
    let grid: AdaptiveGridLayout
    let thumbnailWidth: Double
    let thumbnailHeight: Double

    // Kept as a compatibility convenience while all grid callers migrate to `grid.maxColumns`.
    var columnCount: Int { grid.maxColumns }

    static let list = LibraryCardLayout(
        coverAspectRatio: 116.0 / 76.0,
        titleLineLimit: 2,
        summaryLineLimit: 2,
        tagLimit: 3,
        grid: AdaptiveGridLayout(minItemWidth: 1, maxItemWidth: .greatestFiniteMagnitude, maxColumns: 1),
        thumbnailWidth: 116,
        thumbnailHeight: 76
    )
    // 竖向瀑布流：上图下字，卡片保持在 220–300 pt 之间并优先增列。
    static let waterfall = LibraryCardLayout(
        coverAspectRatio: 0.75,
        titleLineLimit: 3,
        summaryLineLimit: 0,
        tagLimit: 1,
        grid: AdaptiveGridLayout(minItemWidth: 220, maxItemWidth: 300, maxColumns: 4),
        thumbnailWidth: 0,
        thumbnailHeight: 0
    )
    // 矮胖横向卡片：宽封面配合完整摘要，限制为 360–520 pt 并最多三列。
    static let card = LibraryCardLayout(
        coverAspectRatio: 2.35,
        titleLineLimit: 2,
        summaryLineLimit: 2,
        tagLimit: 3,
        grid: AdaptiveGridLayout(minItemWidth: 360, maxItemWidth: 520, maxColumns: 3),
        thumbnailWidth: 0,
        thumbnailHeight: 0
    )
}
