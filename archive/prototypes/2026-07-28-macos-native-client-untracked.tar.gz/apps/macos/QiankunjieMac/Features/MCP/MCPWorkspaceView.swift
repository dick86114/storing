import AppKit
import Observation
import SwiftUI

@MainActor @Observable
private final class MCPFeatureModel {
    var limits: MCPPlatformLimits?
    var clients: [MCPClient] = []
    var logs: [MCPRequestLog] = []
    var error: String?
    var revealedKey: String?
    var creating = false
    var editingClient: MCPClient?
    let api = APIClient.shared

    func load() async {
        do {
            async let loadedLimits: MCPPlatformLimits = api.request(.mcpLimits)
            async let loadedClients: MCPClientsResponse = api.request(.mcpClients)
            async let loadedLogs: MCPLogsResponse = api.request(.mcpLogs)
            limits = try await loadedLimits
            clients = try await loadedClients.clients
            logs = try await loadedLogs.logs
        } catch { self.error = error.localizedDescription }
    }
    func create(name: String, scopes: [String], saveToInbox: Bool) async {
        do { let response: MCPKeyResponse = try await api.request(.mcpClients, body: MCPCreateRequest(name: name, scopes: scopes, enabled: true, defaultSaveToInbox: saveToInbox)); revealedKey = response.apiKey; creating = false; await load() } catch { self.error = error.localizedDescription }
    }
    func update(_ client: MCPClient, scopes: [String], saveToInbox: Bool) async {
        do { let _: MCPClientResponse = try await api.request(.mcpClient(id: client.id), method: .patch, body: MCPUpdateRequest(enabled: nil, scopes: scopes, defaultSaveToInbox: saveToInbox)); editingClient = nil; await load() } catch { self.error = error.localizedDescription }
    }
    func toggle(_ client: MCPClient) async {
        do { let _: MCPClientResponse = try await api.request(.mcpClient(id: client.id), method: .patch, body: MCPUpdateRequest(enabled: !client.enabled, scopes: nil, defaultSaveToInbox: nil)); await load() } catch { self.error = error.localizedDescription }
    }
    func rotate(_ client: MCPClient) async {
        do { let response: MCPKeyResponse = try await api.request(.mcpRotate(id: client.id), method: .post); revealedKey = response.apiKey; await load() } catch { self.error = error.localizedDescription }
    }
    func delete(_ client: MCPClient) async {
        do { let _: MCPDeleteResponse = try await api.request(.mcpClient(id: client.id), method: .delete); await load() } catch { self.error = error.localizedDescription }
    }
}

struct MCPWorkspaceView: View {
    @State private var feature = MCPFeatureModel()
    @State private var tab = 0
    var body: some View {
        @Bindable var feature = feature
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 5) { Text("MCP 设置").font(.largeTitle).fontWeight(.semibold).fontDesign(.serif); Text("Model Context Protocol 连接与 API 密钥管理").foregroundStyle(.secondary) }
                HStack(spacing: 14) { metric("每分钟限额", feature.limits.map { "\($0.rateLimitPerMinute)" } ?? "—", "speedometer"); metric("每日限额", feature.limits.map { "\($0.rateLimitPerDay)" } ?? "—", "calendar"); metric("并发采集", feature.limits.map { "\($0.concurrentCollectLimit)" } ?? "—", "square.stack.3d.up") }
                HStack { Picker("", selection: $tab) { Text("我的连接").tag(0); Text("接入指南").tag(1); Text("调用记录").tag(2) }.pickerStyle(.segmented).frame(width: 280); Spacer(); Button("新建连接") { feature.creating = true }.buttonStyle(.borderedProminent) }
                if tab == 0 { VStack(spacing: 12) { ForEach(feature.clients) { client in clientRow(client) } }; if feature.clients.isEmpty { ContentUnavailableView("还没有 MCP Client", systemImage: "externaldrive.connected.to.line.below") } }
                else if tab == 1 { accessGuide }
                else { VStack(spacing: 9) { ForEach(feature.logs) { log in HStack { Image(systemName: log.status == "error" ? "exclamationmark.triangle" : "checkmark.circle").foregroundStyle(log.status == "error" ? .red : .green); VStack(alignment: .leading) { Text(log.toolName).fontWeight(.semibold); Text([log.status, log.durationMs.map { "\($0)ms" }, log.createdAt].compactMap { $0 }.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary) }; Spacer() }.padding(12).qkCard() } } }
            }.padding(28).frame(maxWidth: 1050, alignment: .leading).frame(maxWidth: .infinity)
        }.task { await feature.load() }
        .sheet(item: $feature.editingClient) { client in EditMCPClientView(client: client) { scopes, save in Task { await feature.update(client, scopes: scopes, saveToInbox: save) } } }
        .sheet(isPresented: $feature.creating) { CreateMCPClientView { name, scopes, save in Task { await feature.create(name: name, scopes: scopes, saveToInbox: save) } } }
        .alert("API Key（仅显示一次）", isPresented: Binding(get: { feature.revealedKey != nil }, set: { if !$0 { feature.revealedKey = nil } })) { Button("复制并关闭") { if let key = feature.revealedKey { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(key, forType: .string) }; feature.revealedKey = nil } } message: { Text(feature.revealedKey ?? "") }
        .alert("MCP 操作失败", isPresented: Binding(get: { feature.error != nil }, set: { if !$0 { feature.error = nil } })) { Button("关闭", role: .cancel) {} } message: { Text(feature.error ?? "") }
    }
    private func metric(_ title: String, _ value: String, _ icon: String) -> some View { VStack(alignment: .leading, spacing: 7) { Label(title, systemImage: icon).foregroundStyle(.secondary); Text(value).font(.title).fontWeight(.semibold) }.padding(18).frame(maxWidth: .infinity, alignment: .leading).qkCard() }
    private var accessGuide: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("Bearer API Key 接入", systemImage: "key.horizontal").font(.title2).foregroundStyle(QKColor.gold)
            Text("乾坤戒 MCP 当前使用自定义 Bearer API Key，不提供 OAuth。创建或轮换 Key 后请立即复制，关闭后无法再次查看。")
            VStack(alignment: .leading, spacing: 8) {
                Text("服务地址").font(.headline)
                Text("https://storing.idickies.com/mcp").textSelection(.enabled).padding(10).background(.quaternary, in: RoundedRectangle(cornerRadius: 8))
                Text("请求头").font(.headline)
                Text("Authorization: Bearer <API_KEY>").textSelection(.enabled).padding(10).background(.quaternary, in: RoundedRectangle(cornerRadius: 8))
            }
        }.padding(20).qkCard()
    }
    private func clientRow(_ client: MCPClient) -> some View { HStack { VStack(alignment: .leading, spacing: 7) { HStack { Text(client.name).font(.headline); Text(client.enabled ? "已启用" : "已暂停").font(.caption).foregroundStyle(client.enabled ? .green : .orange) }; HStack { ForEach(client.scopes, id: \.self) { Text($0).font(.caption2).padding(.horizontal, 7).padding(.vertical, 3).background(.quaternary, in: Capsule()) } } }; Spacer(); Menu { Button("编辑权限") { feature.editingClient = client }; Button(client.enabled ? "暂停" : "恢复") { Task { await feature.toggle(client) } }; Button("轮换 Key") { Task { await feature.rotate(client) } }; Button("删除", role: .destructive) { Task { await feature.delete(client) } } } label: { Image(systemName: "ellipsis.circle") } }.padding(16).qkCard() }
}

private struct CreateMCPClientView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""; @State private var save = true
    @State private var scopes: Set<String> = ["summary:create", "collect:create", "inbox:write", "job:read:self"]
    let submit: (String, [String], Bool) -> Void
    var body: some View { VStack(alignment: .leading, spacing: 16) { Text("创建 MCP Client").font(.title2).fontWeight(.semibold); TextField("Client 名称", text: $name); ForEach(["summary:create", "collect:create", "inbox:write", "job:read:self"], id: \.self) { scope in Toggle(scope, isOn: Binding(get: { scopes.contains(scope) }, set: { if $0 { scopes.insert(scope) } else { scopes.remove(scope) } })) }; Toggle("采集默认保存到收件箱", isOn: $save); HStack { Button("取消") { dismiss() }; Spacer(); Button("创建") { submit(name, Array(scopes), save) }.buttonStyle(.borderedProminent).disabled(name.count < 2) } }.padding(24).frame(width: 420) }
}

private struct EditMCPClientView: View {
    @Environment(\.dismiss) private var dismiss
    let client: MCPClient
    let submit: ([String], Bool) -> Void
    @State private var scopes: Set<String>
    @State private var save: Bool
    init(client: MCPClient, submit: @escaping ([String], Bool) -> Void) { self.client = client; self.submit = submit; _scopes = State(initialValue: Set(client.scopes)); _save = State(initialValue: client.defaultSaveToInbox) }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("编辑 \(client.name)").font(.title2).fontWeight(.semibold)
            ForEach(["summary:create", "collect:create", "inbox:write", "job:read:self"], id: \.self) { scope in Toggle(scope, isOn: Binding(get: { scopes.contains(scope) }, set: { if $0 { scopes.insert(scope) } else { scopes.remove(scope) } })) }
            Toggle("采集默认保存到收件箱", isOn: $save)
            HStack { Button("取消") { dismiss() }; Spacer(); Button("保存") { submit(Array(scopes), save) }.buttonStyle(.borderedProminent) }
        }.padding(24).frame(width: 430)
    }
}
