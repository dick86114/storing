import AppKit
import LocalAuthentication
import SwiftUI

struct SettingsWorkspaceView: View {
    @Environment(AppModel.self) private var model
    @AppStorage("appearance") private var appearance = "system"
    @AppStorage("reader.textScale") private var textScale = 1.0
    @AppStorage("reader.lineHeight") private var lineHeight = 1.8
    @AppStorage("reader.padding") private var readerPadding = 28.0
    @AppStorage("security.touchID") private var touchID = false
    @AppStorage("menubar.enabled") private var menuBarEnabled = true
    @AppStorage("launchAtLogin") private var launchAtLogin = false
    @AppStorage("globalShortcut.id") private var globalShortcutID = GlobalShortcutDescriptor.defaultPreset.id
    @State private var biometricMessage: String?
    @State private var systemIntegrationMessage: String?
    @State private var showSessions = false
    @State private var showPassword = false
    @State private var showOffline = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text("设置").font(.largeTitle).fontWeight(.semibold).fontDesign(.serif)
                settingsGroup("外观与阅读") {
                    LabeledContent("外观") { Picker("", selection: $appearance) { Text("跟随系统").tag("system"); Text("浅色").tag("light"); Text("深色").tag("dark") }.frame(width: 180) }
                    LabeledContent("正文大小") { Slider(value: $textScale, in: 0.85...1.35, step: 0.05).frame(width: 220); Text("\(Int(textScale * 100))%") }
                    LabeledContent("行距") { Slider(value: $lineHeight, in: 1.4...2.4, step: 0.1).frame(width: 220); Text(lineHeight.formatted(.number.precision(.fractionLength(1)))) }
                    LabeledContent("页面边距") { Slider(value: $readerPadding, in: 16...56, step: 4).frame(width: 220); Text("\(Int(readerPadding))") }
                }
                settingsGroup("安全与系统集成") {
                    Toggle("使用 Touch ID 锁定应用", isOn: $touchID).onChange(of: touchID) { _, enabled in if enabled { verifyBiometrics() } }
                    Toggle("在菜单栏显示", isOn: $menuBarEnabled)
                        .onChange(of: menuBarEnabled) { _, enabled in model.configureMenuBar(enabled: enabled) }
                    LabeledContent("全局快速采集") {
                        Picker("", selection: $globalShortcutID) {
                            ForEach(GlobalShortcutDescriptor.presets) { shortcut in
                                Text(shortcut.displayName).tag(shortcut.id)
                            }
                        }
                        .frame(width: 150)
                        .onChange(of: globalShortcutID) { _, id in model.configureGlobalShortcut(id: id) }
                    }
                    Toggle("登录时启动（本地自用版本默认关闭）", isOn: $launchAtLogin)
                        .onChange(of: launchAtLogin) { _, enabled in updateLaunchAtLogin(enabled) }
                    if let biometricMessage { Text(biometricMessage).font(.caption).foregroundStyle(.secondary) }
                    if let systemIntegrationMessage { Text(systemIntegrationMessage).font(.caption).foregroundStyle(.secondary) }
                }
                settingsGroup("存储、诊断与账户") {
                    Button("设备会话") { showSessions = true }
                    Button("修改密码") { showPassword = true }
                    Button("离线内容管理") { showOffline = true }
                    Button("清理图片缓存") { URLCache.shared.removeAllCachedResponses() }
                    Button("导出诊断信息") { exportDiagnostics() }
                    LabeledContent("API") { Text(APIEndpoint.baseURL.absoluteString).foregroundStyle(.secondary).textSelection(.enabled) }
                    LabeledContent("版本") { Text("\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.1.0") (\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"))") }
                    if model.user != nil { Button("退出当前设备", role: .destructive) { Task { await model.logout() } } }
                    else { Button("登录") { model.showsLogin = true } }
                }
            }.padding(28).frame(maxWidth: 900, alignment: .leading).frame(maxWidth: .infinity)
        }
        .task {
            let status = LaunchAtLoginController.status
            launchAtLogin = status.isPresentedAsEnabled
            if status == .requiresApproval { systemIntegrationMessage = "请在系统设置的“登录项”中允许乾坤戒。" }
        }
        .sheet(isPresented: $showSessions) { DeviceSessionsView() }
        .sheet(isPresented: $showPassword) { ChangePasswordView() }
        .sheet(isPresented: $showOffline) { OfflineContentView() }
    }


    private func updateLaunchAtLogin(_ enabled: Bool) {
        guard enabled != LaunchAtLoginController.status.isPresentedAsEnabled else { return }
        do {
            let status = try LaunchAtLoginController.setEnabled(enabled)
            launchAtLogin = status.isPresentedAsEnabled
            systemIntegrationMessage = status == .requiresApproval ? "已提交登录项，请在系统设置中批准。" : (status == .enabled ? "已启用登录时启动" : "已关闭登录时启动")
        } catch {
            launchAtLogin = LaunchAtLoginController.status.isPresentedAsEnabled
            systemIntegrationMessage = "登录项更新失败：\(error.localizedDescription)"
        }
    }

    private func settingsGroup<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) { Text(title).font(.headline).foregroundStyle(QKColor.gold); content() }.padding(20).qkCard()
    }

    private func verifyBiometrics() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else { touchID = false; biometricMessage = "当前 Mac 未配置可用的 Touch ID。"; return }
        context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "启用乾坤戒应用锁") { success, error in
            Task { @MainActor in self.touchID = success; self.biometricMessage = success ? "Touch ID 已启用" : (error?.localizedDescription ?? "验证失败") }
        }
    }

    private func exportDiagnostics() {
        let text = """
        乾坤戒 macOS 诊断信息
        version=\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "unknown")
        build=\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "unknown")
        os=\(ProcessInfo.processInfo.operatingSystemVersionString)
        api=\(APIEndpoint.baseURL.host ?? "unknown")
        user_state=\(model.user == nil ? "guest" : "authenticated")
        """
        let panel = NSSavePanel(); panel.nameFieldStringValue = "qiankunjie-diagnostics.txt"
        if panel.runModal() == .OK, let url = panel.url { try? text.write(to: url, atomically: true, encoding: .utf8) }
    }
}

private struct DeviceSessionsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var sessions: [NativeSessionSummary] = []
    @State private var error: String?
    var body: some View {
        VStack(spacing: 0) {
            HStack { Text("登录设备").font(.title2).fontWeight(.semibold); Spacer(); Button("关闭") { dismiss() } }.padding(18)
            Divider()
            if sessions.isEmpty { ContentUnavailableView("暂无设备会话", systemImage: "desktopcomputer") }
            else { List(sessions) { session in HStack { Image(systemName: session.platform == "macos" ? "macbook" : "smartphone").foregroundStyle(QKColor.gold); VStack(alignment: .leading) { Text(session.deviceName ?? "未知设备").fontWeight(.semibold); Text("\(session.platform ?? "native") · v\(session.appVersion ?? "—") · 最近使用 \(session.lastUsedAt?.prefix(19) ?? "—")").font(.caption).foregroundStyle(.secondary) }; Spacer(); if session.revokedAt == nil { Button("撤销", role: .destructive) { Task { await revoke(session) } } } } } }
        }.frame(width: 640, height: 440).task { await load() }
        .alert("设备会话操作失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("关闭", role: .cancel) {} } message: { Text(error ?? "") }
    }
    private func load() async { do { let response: NativeSessionsResponse = try await APIClient.shared.request(.nativeSessions); sessions = response.sessions } catch { self.error = error.localizedDescription } }
    private func revoke(_ session: NativeSessionSummary) async { do { let _: MessageResponse = try await APIClient.shared.request(.revokeSession(session.id), method: .delete); await load() } catch { self.error = error.localizedDescription } }
}

private struct ChangePasswordView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var current = ""; @State private var next = ""; @State private var confirm = ""; @State private var error: String?
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("修改密码").font(.title2).fontWeight(.semibold)
            Text("修改后会撤销所有原生客户端会话，需要重新登录。").font(.caption).foregroundStyle(.secondary)
            SecureField("当前密码", text: $current); SecureField("新密码（至少 12 位）", text: $next); SecureField("确认新密码", text: $confirm)
            if let error { Text(error).font(.caption).foregroundStyle(.red) }
            HStack { Button("取消") { dismiss() }; Spacer(); Button("确认修改") { Task { await submit() } }.buttonStyle(.borderedProminent).disabled(current.isEmpty || next.count < 12 || next != confirm) }
        }.padding(24).frame(width: 430)
    }
    private func submit() async {
        struct Body: Codable, Sendable { let currentPassword: String; let newPassword: String }
        do { let _: MessageResponse = try await APIClient.shared.request(.changePassword, method: .post, body: Body(currentPassword: current, newPassword: next)); dismiss() } catch { self.error = error.localizedDescription }
    }
}

private struct OfflineContentView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var items: [OfflineArticleManifest] = []
    @State private var error: String?
    private var total: Int64 { items.reduce(0) { $0 + $1.totalSize } }
    var body: some View {
        VStack(spacing: 0) {
            HStack { VStack(alignment: .leading) { Text("离线内容").font(.title2).fontWeight(.semibold); Text("\(items.count) 篇 · \(ByteCountFormatter.string(fromByteCount: total, countStyle: .file))").font(.caption).foregroundStyle(.secondary) }; Spacer(); Button("清理全部", role: .destructive) { Task { await clear() } }.disabled(items.isEmpty); Button("关闭") { dismiss() } }.padding(18)
            Divider()
            if items.isEmpty { ContentUnavailableView("还没有离线内容", systemImage: "arrow.down.circle", description: Text("在文章阅读器中选择“下载离线内容”。")) }
            else { List(items) { item in HStack { Image(systemName: "doc.richtext.fill").foregroundStyle(QKColor.gold); VStack(alignment: .leading) { Text(item.title).fontWeight(.semibold); Text("\(item.source ?? "未知来源") · \(item.imageCount) 张图片 · \(ByteCountFormatter.string(fromByteCount: item.totalSize, countStyle: .file))").font(.caption).foregroundStyle(.secondary) }; Spacer(); Button(role: .destructive) { Task { await delete(item) } } label: { Image(systemName: "trash") } } } }
        }.frame(width: 720, height: 500).task { await load() }
        .alert("离线内容操作失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("关闭", role: .cancel) {} } message: { Text(error ?? "") }
    }
    private func load() async { guard let id = model.user?.id else { return }; do { items = try await model.offlineStore.list(userId: id) } catch { self.error = error.localizedDescription } }
    private func delete(_ item: OfflineArticleManifest) async { do { try await model.offlineStore.delete(articleId: item.id, userId: item.userId); await load() } catch { self.error = error.localizedDescription } }
    private func clear() async { guard let id = model.user?.id else { return }; do { try await model.offlineStore.clear(userId: id); await load() } catch { self.error = error.localizedDescription } }
}
