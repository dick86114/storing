import AppKit
import SwiftUI

struct CollectWorkspaceView: View {
    @Environment(AppModel.self) private var model
    @State private var input = ""
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 6) { Text("采集").font(.largeTitle).fontWeight(.semibold).fontDesign(.serif); Text("保存公开网页到你的个人资料库，并自动生成摘要、分类和标签。 ").foregroundStyle(.secondary) }
                VStack(alignment: .leading, spacing: 14) {
                    Text("输入文章链接").font(.headline)
                    HStack { TextField("https://example.com/article", text: $input).textFieldStyle(.roundedBorder); Button("粘贴") { input = NSPasteboard.general.string(forType: .string) ?? "" }; Button("开始采集") { submit() }.buttonStyle(.borderedProminent).disabled(IncomingCollectRouter.extractURLs(from: input).isEmpty) }
                    Text("也可以将浏览器地址或选中文本直接拖放到窗口。支持 ⌥⌘S 快速采集。 ").font(.caption).foregroundStyle(.secondary)
                }.padding(22).qkCard()
                HStack { Text("最近任务").font(.title2).fontWeight(.semibold); Spacer(); Button("刷新") { Task { await model.loadJobs() } } }
                CollectJobsList(jobs: model.jobs, onRetry: { job in Task { await model.retryJob(job) } }, onDelete: { job in Task { await model.deleteJob(job) } })
            }.padding(28).frame(maxWidth: 980, alignment: .leading).frame(maxWidth: .infinity)
        }
        .dropDestination(for: URL.self) { urls, _ in if let first = urls.first { input = first.absoluteString; return true }; return false }
        .task { await model.loadJobs() }
    }
    private func submit() { guard let url = IncomingCollectRouter.extractURLs(from: input).first else { return }; Task { if await model.submitCollect(url: url) { input = "" } } }
}

struct CollectConfirmationView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var input = ""
    @State private var candidates: [URL] = []
    @State private var selectedURLs = Set<URL>()

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Label("快速采集", systemImage: "plus.circle.fill").font(.title2).foregroundStyle(QKColor.gold)
            TextEditor(text: $input)
                .font(.body.monospaced())
                .frame(minHeight: candidates.count > 1 ? 70 : 42, maxHeight: 90)
                .padding(7)
                .background(.quaternary.opacity(0.28), in: RoundedRectangle(cornerRadius: 8))
                .onChange(of: input) { _, value in refreshCandidates(from: value) }
            if let request = PendingCollectPresentation.shared.request, let title = request.title {
                Text(title).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
            }
            if candidates.count > 1 {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Label("检测到 \(candidates.count) 个链接", systemImage: "link.badge.plus").font(.headline)
                        Spacer()
                        Button(selectedURLs.count == candidates.count ? "取消全选" : "全选") {
                            selectedURLs = selectedURLs.count == candidates.count ? [] : Set(candidates)
                        }.buttonStyle(.plain).foregroundStyle(QKColor.gold)
                    }
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(candidates, id: \.self) { url in
                                Toggle(isOn: Binding(get: { selectedURLs.contains(url) }, set: { selected in
                                    if selected { selectedURLs.insert(url) } else { selectedURLs.remove(url) }
                                })) {
                                    Text(url.absoluteString).font(.caption.monospaced()).lineLimit(2).textSelection(.enabled)
                                }
                                .toggleStyle(.checkbox)
                            }
                        }
                    }.frame(maxHeight: 180)
                }
                .padding(14).qkCard()
                .transition(.move(edge: .top).combined(with: .opacity))
            }
            HStack {
                Button("取消") { PendingCollectPresentation.shared.request = nil; dismiss() }
                Spacer()
                Button("保存 \(selectedURLs.count) 个链接") { submit() }
                    .buttonStyle(.borderedProminent)
                    .disabled(selectedURLs.isEmpty)
            }
        }
        .padding(24)
        .frame(width: 560)
        .animation(.snappy(duration: 0.24), value: candidates)
        .onAppear {
            let requestURLs = PendingCollectPresentation.shared.request?.urls ?? []
            input = requestURLs.isEmpty
                ? (NSPasteboard.general.string(forType: .string) ?? "")
                : requestURLs.map(\.absoluteString).joined(separator: "\n")
            refreshCandidates(from: input, selectAll: true)
        }
    }

    private func refreshCandidates(from text: String, selectAll: Bool = false) {
        let next = IncomingCollectRouter.extractURLs(from: text)
        let previous = selectedURLs
        let previousCandidates = Set(candidates)
        candidates = next
        selectedURLs = selectAll ? Set(next) : Set(next.filter { previous.contains($0) || !previousCandidates.contains($0) })
        if !selectAll, selectedURLs.isEmpty, next.count == 1 { selectedURLs = Set(next) }
    }

    private func submit() {
        let urls = candidates.filter(selectedURLs.contains)
        let source = PendingCollectPresentation.shared.request?.source ?? .manual
        Task {
            if await model.submitCollect(urls: urls, source: source) {
                PendingCollectPresentation.shared.request = nil
                dismiss()
            }
        }
    }
}

struct CollectJobsView: View {
    @Environment(AppModel.self) private var model
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("采集任务").font(.title2).fontWeight(.semibold).fontDesign(.serif)
                Spacer()
                Button("清理已完成") { Task { await model.clearFinishedJobs() } }
                Button("刷新") { Task { await model.loadJobs() } }
            }
            .padding(18)
            Divider()
            ScrollView {
                CollectJobsList(
                    jobs: model.jobs,
                    onRetry: { job in Task { await model.retryJob(job) } },
                    onDelete: { job in Task { await model.deleteJob(job) } }
                )
                .padding(18)
            }
        }
        .task { await model.loadJobs() }
    }
}

struct CollectJobsList: View {
    let jobs: [CollectJob]
    var onRetry: (CollectJob) -> Void = { _ in }
    var onDelete: (CollectJob) -> Void = { _ in }

    var body: some View {
        if jobs.isEmpty {
            ContentUnavailableView("暂无采集任务", systemImage: "clock.arrow.circlepath")
        } else {
            LazyVStack(spacing: 10) {
                ForEach(jobs) { job in
                    HStack(spacing: 12) {
                        Image(systemName: icon(job)).foregroundStyle(color(job))
                        VStack(alignment: .leading, spacing: 4) {
                            Text(job.title?.nilIfEmpty ?? job.url).fontWeight(.semibold).lineLimit(1)
                            Text("\(job.status) · \(job.stage)").font(.caption).foregroundStyle(.secondary)
                            if let error = job.errorSummary { Text(error).font(.caption).foregroundStyle(.red) }
                        }
                        Spacer()
                        if job.status == "failed" { Button("重试") { onRetry(job) } }
                        if job.isTerminal {
                            Button(role: .destructive) { onDelete(job) } label: { Image(systemName: "trash") }.help("删除任务")
                        }
                    }
                    .padding(13)
                    .qkCard()
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .animation(.snappy, value: jobs)
        }
    }
    private func icon(_ job: CollectJob) -> String { job.status == "completed" ? "checkmark.circle.fill" : job.status == "failed" ? "xmark.circle.fill" : "arrow.trianglehead.2.clockwise.rotate.90" }
    private func color(_ job: CollectJob) -> Color { job.status == "completed" ? .green : job.status == "failed" ? .red : QKColor.gold }
}

struct MenuBarView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openWindow) private var openWindow
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Image(systemName: "circle.hexagongrid.fill").foregroundStyle(QKColor.gold); Text("乾坤戒").fontWeight(.semibold); Spacer(); Text(model.user?.username ?? "游客").font(.caption).foregroundStyle(.secondary) }
            Button("快速采集剪贴板链接") { model.showsCollect = true; openWindow(id: "main"); NSApp.activate() }.keyboardShortcut("s", modifiers: [.command, .option])
            Button("打开主窗口") { openWindow(id: "main"); NSApp.activate() }
            Divider()
            Text("进行中任务：\(model.jobs.filter { !$0.isTerminal }.count)").font(.caption).foregroundStyle(.secondary)
            Button("退出乾坤戒") { NSApp.terminate(nil) }
        }.padding(14).frame(width: 280)
    }
}
