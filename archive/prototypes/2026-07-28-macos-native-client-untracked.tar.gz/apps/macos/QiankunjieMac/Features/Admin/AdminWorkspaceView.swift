import Observation
import SwiftUI

@MainActor @Observable
private final class AdminFeatureModel {
    var users: [AdminUser] = []
    var clients: [MCPClient] = []
    var limits: MCPPlatformLimits?
    var auditLogs: [AdminAuditLog] = []
    var requestLogs: [MCPRequestLog] = []
    var error: String?
    var editingUser: AdminUser?
    var creatingUser = false
    var editingLimits = false
    let api = APIClient.shared

    func load() async {
        do {
            async let usersResponse: AdminUsersResponse = api.request(.adminUsers)
            async let clientsResponse: MCPClientsResponse = api.request(.adminMcpClients)
            async let limitsResponse: MCPPlatformLimits = api.request(.adminMcpLimits)
            async let auditResponse: AdminAuditLogsResponse = api.request(.adminAuditLogs)
            async let requestResponse: MCPLogsResponse = api.request(.adminMcpLogs)
            users = try await usersResponse.users
            clients = try await clientsResponse.clients
            limits = try await limitsResponse
            auditLogs = try await auditResponse.logs
            requestLogs = try await requestResponse.logs
        } catch { self.error = error.localizedDescription }
    }

    func saveLimits(perMinute: Int, perDay: Int, concurrent: Int) async {
        do {
            let body = MCPPlatformLimits(rateLimitPerMinute: perMinute, rateLimitPerDay: perDay, concurrentCollectLimit: concurrent)
            limits = try await api.request(.adminMcpLimits, method: .patch, body: body)
            editingLimits = false
        } catch { self.error = error.localizedDescription }
    }

    func saveUser(id: Int?, username: String, password: String?, role: String, status: String) async {
        do {
            let body = AdminUserMutation(username: username.nilIfEmpty, password: password?.nilIfEmpty, role: role, status: status)
            let _: AdminUserResponse
            if let id { _ = try await api.request(.adminUser(id: id), method: .patch, body: body) as AdminUserResponse }
            else { _ = try await api.request(.adminUsers, method: .post, body: body) as AdminUserResponse }
            editingUser = nil; creatingUser = false; await load()
        } catch { self.error = error.localizedDescription }
    }
}

struct AdminWorkspaceView: View {
    @State private var feature = AdminFeatureModel()
    @State private var tab = 0
    var body: some View {
        @Bindable var feature = feature
        VStack(spacing: 0) {
            HStack { VStack(alignment: .leading) { Text("管理员后台").font(.title2).fontWeight(.semibold).fontDesign(.serif); Text("用户、MCP 平台与审计日志").font(.caption).foregroundStyle(.secondary) }; Spacer(); if tab == 0 { Button("新建用户") { feature.creatingUser = true }.buttonStyle(.borderedProminent) }; Button("刷新") { Task { await feature.load() } } }.padding(18)
            Divider()
            Picker("", selection: $tab) { Text("用户管理").tag(0); Text("MCP 平台").tag(1); Text("审计日志").tag(2) }.pickerStyle(.segmented).frame(width: 420).padding()
            ScrollView {
                Group {
                    if tab == 0 {
                        adminUsers
                    } else if tab == 1 {
                        mcpPlatform
                    } else {
                        auditLogs
                    }
                }
                .padding(20)
            }
        }
        .task { await feature.load() }
        .sheet(isPresented: $feature.creatingUser) { UserEditorView(user: nil) { username, password, role, status in Task { await feature.saveUser(id: nil, username: username, password: password, role: role, status: status) } } }
        .sheet(isPresented: $feature.editingLimits) { LimitsEditorView(limits: feature.limits) { minute, day, concurrent in Task { await feature.saveLimits(perMinute: minute, perDay: day, concurrent: concurrent) } } }
        .sheet(item: $feature.editingUser) { user in UserEditorView(user: user) { username, password, role, status in Task { await feature.saveUser(id: user.id, username: username, password: password, role: role, status: status) } } }
        .alert("管理员操作失败", isPresented: Binding(get: { feature.error != nil }, set: { if !$0 { feature.error = nil } })) { Button("关闭", role: .cancel) {} } message: { Text(feature.error ?? "") }
    }

    private var adminUsers: some View {
        LazyVStack(spacing: 10) {
            if feature.users.isEmpty { ContentUnavailableView("暂无用户数据", systemImage: "person.3") }
            ForEach(feature.users) { user in
                HStack { Circle().fill(QKColor.gold.opacity(0.25)).frame(width: 32, height: 32).overlay(Text(String(user.username.prefix(1)))); VStack(alignment: .leading) { Text(user.username).fontWeight(.semibold); Text("收件箱 \(user.inboxCount) · 归档 \(user.archiveCount) · 收藏 \(user.favoriteCount) · MCP \(user.mcpClientCount)").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(user.role).font(.caption); Text(user.status == "active" ? "活跃" : "停用").foregroundStyle(user.status == "active" ? .green : .red); Button("编辑") { feature.editingUser = user } }.padding(13).qkCard()
            }
        }
    }
    private var mcpPlatform: some View {
        VStack(spacing: 18) {
            HStack { Text("平台默认配额").font(.headline); Spacer(); Button("修改配额") { feature.editingLimits = true } }
            HStack(spacing: 14) { metric("平台 Clients", "\(feature.clients.count)"); metric("每分钟默认限额", feature.limits.map { "\($0.rateLimitPerMinute)" } ?? "—"); metric("每日默认限额", feature.limits.map { "\($0.rateLimitPerDay)" } ?? "—") }
            LazyVStack(spacing: 9) { ForEach(feature.clients) { client in HStack { VStack(alignment: .leading) { Text(client.name).fontWeight(.semibold); Text(client.ownerUsername ?? "用户 #\(client.ownerUserId)").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(client.enabled ? "启用" : "暂停").foregroundStyle(client.enabled ? .green : .orange); Text(client.scopes.joined(separator: " · ")).font(.caption).lineLimit(1) }.padding(12).qkCard() } }
        }
    }
    private var auditLogs: some View { LazyVStack(alignment: .leading, spacing: 10) { ForEach(feature.auditLogs) { log in HStack { Image(systemName: "checkmark.shield").foregroundStyle(QKColor.gold); VStack(alignment: .leading) { Text(log.action).fontWeight(.semibold); Text([log.actorUsername, log.targetUsername, log.articleTitle].compactMap { $0 }.joined(separator: " → ")).font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(log.createdAt?.prefix(19) ?? "").font(.caption).foregroundStyle(.secondary) }.padding(13).qkCard() } } }
    private func metric(_ title: String, _ value: String) -> some View { VStack(alignment: .leading) { Text(title).foregroundStyle(.secondary); Text(value).font(.title).fontWeight(.semibold) }.padding(18).frame(maxWidth: .infinity, alignment: .leading).qkCard() }
}

private struct UserEditorView: View {
    @Environment(\.dismiss) private var dismiss
    let user: AdminUser?
    let save: (String, String?, String, String) -> Void
    @State private var username: String; @State private var password = ""; @State private var role: String; @State private var status: String
    init(user: AdminUser?, save: @escaping (String, String?, String, String) -> Void) { self.user = user; self.save = save; _username = State(initialValue: user?.username ?? ""); _role = State(initialValue: user?.role ?? "user"); _status = State(initialValue: user?.status ?? "active") }
    var body: some View { VStack(alignment: .leading, spacing: 16) { Text(user == nil ? "创建用户" : "编辑用户").font(.title2).fontWeight(.semibold); TextField("用户名", text: $username); SecureField(user == nil ? "密码（至少 12 位）" : "新密码（留空则不修改）", text: $password); Picker("角色", selection: $role) { Text("普通用户").tag("user"); Text("管理员").tag("admin"); Text("服务账号").tag("service") }; Picker("状态", selection: $status) { Text("启用").tag("active"); Text("停用").tag("disabled") }; HStack { Button("取消") { dismiss() }; Spacer(); Button("保存") { save(username, password.nilIfEmpty, role, status) }.buttonStyle(.borderedProminent).disabled(username.count < 2 || (user == nil && password.count < 12)) } }.padding(24).frame(width: 420) }
}

private struct LimitsEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var minute: Int
    @State private var day: Int
    @State private var concurrent: Int
    let save: (Int, Int, Int) -> Void
    init(limits: MCPPlatformLimits?, save: @escaping (Int, Int, Int) -> Void) {
        _minute = State(initialValue: limits?.rateLimitPerMinute ?? 20)
        _day = State(initialValue: limits?.rateLimitPerDay ?? 500)
        _concurrent = State(initialValue: limits?.concurrentCollectLimit ?? 3)
        self.save = save
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text("修改平台默认配额").font(.title2).fontWeight(.semibold)
            Stepper("每分钟限额：\(minute)", value: $minute, in: 1...10_000)
            Stepper("每日限额：\(day)", value: $day, in: 1...1_000_000)
            Stepper("并发采集数：\(concurrent)", value: $concurrent, in: 1...100)
            HStack { Button("取消") { dismiss() }; Spacer(); Button("保存") { save(minute, day, concurrent) }.buttonStyle(.borderedProminent) }
        }.padding(24).frame(width: 420)
    }
}
