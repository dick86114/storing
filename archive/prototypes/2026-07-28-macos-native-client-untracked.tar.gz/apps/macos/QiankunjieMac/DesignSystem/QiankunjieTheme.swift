import SwiftUI

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xff) / 255,
                  green: Double((hex >> 8) & 0xff) / 255,
                  blue: Double(hex & 0xff) / 255,
                  opacity: alpha)
    }
}


enum AppAppearance: String, CaseIterable, Sendable {
    case system, light, dark

    init(storedValue: String) {
        self = Self(rawValue: storedValue) ?? .system
    }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }
}

enum QKColor {
    static let ink = Color(hex: 0x071A12)
    static let bamboo = Color(hex: 0x0D2B1E)
    static let bambooRaised = Color(hex: 0x143C30)
    static let gold = Color(hex: 0xC9A84C)
    static let paper = Color(hex: 0xF5F1E8)
    static let paperRaised = Color(hex: 0xFFFFFF)
    static let paperMuted = Color(hex: 0xEDE9DE)
    static let textDark = Color(hex: 0x1A2E24)
    static let secondary = Color(hex: 0x5A7062)
}

struct QKCardModifier: ViewModifier {
    @Environment(\.colorScheme) private var colorScheme
    func body(content: Content) -> some View {
        content
            .background(colorScheme == .dark ? QKColor.bambooRaised : QKColor.paperRaised)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorScheme == .dark ? Color.white.opacity(0.08) : Color.black.opacity(0.08)))
            .shadow(color: .black.opacity(colorScheme == .dark ? 0.18 : 0.06), radius: 7, y: 3)
    }
}

extension View {
    func qkCard() -> some View { modifier(QKCardModifier()) }
}
