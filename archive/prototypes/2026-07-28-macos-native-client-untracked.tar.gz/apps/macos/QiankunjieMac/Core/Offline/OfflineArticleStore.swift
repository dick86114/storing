import CryptoKit
import Foundation

struct ReaderPreferences: Equatable, Sendable {
    var textScale: Double
    var lineHeight: Double
    var horizontalPadding: Double

    var css: String {
        "font-size:\(Int((textScale * 100).rounded()))%;line-height:\(lineHeight.formatted(.number.precision(.fractionLength(2))));padding:42px \(Int(horizontalPadding.rounded()))px"
    }
}

enum OfflineHTMLProcessor {
    private static let expression = try! NSRegularExpression(pattern: #"<img[^>]+src\s*=\s*["']([^"']+)["']"#, options: [.caseInsensitive])

    static func remoteImageURLs(in html: String) -> [URL] {
        let range = NSRange(html.startIndex..<html.endIndex, in: html)
        var seen = Set<String>()
        return expression.matches(in: html, range: range).compactMap { match in
            guard let valueRange = Range(match.range(at: 1), in: html),
                  let url = URL(string: String(html[valueRange])),
                  ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
                  seen.insert(url.absoluteString).inserted else { return nil }
            return url
        }
    }

    static func rewrite(html: String, replacements: [String: String]) -> String {
        replacements.reduce(html) { result, item in result.replacingOccurrences(of: item.key, with: item.value) }
    }
}

struct OfflineArticleManifest: Codable, Identifiable, Sendable {
    let id: Int
    let userId: Int
    let title: String
    let source: String?
    let downloadedAt: Date
    let imageCount: Int
    let coverFile: String?
    let totalSize: Int64
    let article: ArticleDetail
}

struct OfflineArticlePackage: Sendable {
    let manifest: OfflineArticleManifest
    let htmlFile: URL
    let directory: URL
}

actor OfflineArticleStore {
    static let shared = OfflineArticleStore()
    private let root: URL
    private let session: URLSession

    init(root: URL? = nil, session: URLSession = .shared) {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        self.root = root ?? support.appending(path: "Qiankunjie/offline", directoryHint: .isDirectory)
        self.session = session
    }

    func download(article: ArticleDetail, userId: Int) async throws -> OfflineArticlePackage {
        guard let html = article.contentHtml?.nilIfEmpty else { throw OfflineStoreError.missingHTML }
        let fm = FileManager.default
        let userRoot = root.appending(path: String(userId), directoryHint: .isDirectory)
        let staging = userRoot.appending(path: ".staging-\(article.id)-\(UUID().uuidString)", directoryHint: .isDirectory)
        let images = staging.appending(path: "images", directoryHint: .isDirectory)
        try fm.createDirectory(at: images, withIntermediateDirectories: true)
        do {
            var replacements: [String: String] = [:]
            var imageCount = 0
            for url in OfflineHTMLProcessor.remoteImageURLs(in: html) {
                do {
                    let (data, response) = try await session.data(from: url)
                    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode), !data.isEmpty else { continue }
                    let name = Self.assetName(for: url, mimeType: http.mimeType)
                    try data.write(to: images.appending(path: name), options: .atomic)
                    replacements[url.absoluteString] = "images/\(name)"
                    imageCount += 1
                } catch { continue }
            }
            var coverFile: String?
            if let coverRaw = article.coverImage, let coverURL = URL(string: coverRaw) {
                do {
                    let (data, response) = try await session.data(from: coverURL)
                    if let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode), !data.isEmpty {
                        let name = "cover.\((coverURL.pathExtension.nilIfEmpty ?? http.mimeType?.split(separator: "/").last.map(String.init) ?? "jpg").prefix(8))"
                        try data.write(to: staging.appending(path: name), options: .atomic)
                        coverFile = name
                    }
                } catch { }
            }
            let rewritten = OfflineHTMLProcessor.rewrite(html: html, replacements: replacements)
            let htmlFile = staging.appending(path: "content.html")
            try rewritten.write(to: htmlFile, atomically: true, encoding: .utf8)
            let payload = try JSONEncoder.storing.encode(article)
            try payload.write(to: staging.appending(path: "article.json"), options: .atomic)
            let size = try Self.directorySize(staging)
            let manifest = OfflineArticleManifest(id: article.id, userId: userId, title: article.displayTitle, source: article.source, downloadedAt: .now, imageCount: imageCount, coverFile: coverFile, totalSize: size, article: article)
            try JSONEncoder.storing.encode(manifest).write(to: staging.appending(path: "manifest.json"), options: .atomic)
            let destination = userRoot.appending(path: String(article.id), directoryHint: .isDirectory)
            if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
            try fm.moveItem(at: staging, to: destination)
            return OfflineArticlePackage(manifest: manifest, htmlFile: destination.appending(path: "content.html"), directory: destination)
        } catch {
            try? fm.removeItem(at: staging)
            throw error
        }
    }

    func package(articleId: Int, userId: Int) throws -> OfflineArticlePackage? {
        let directory = root.appending(path: String(userId)).appending(path: String(articleId))
        let manifestURL = directory.appending(path: "manifest.json")
        guard FileManager.default.fileExists(atPath: manifestURL.path) else { return nil }
        let manifest = try JSONDecoder.storing.decode(OfflineArticleManifest.self, from: Data(contentsOf: manifestURL))
        return OfflineArticlePackage(manifest: manifest, htmlFile: directory.appending(path: "content.html"), directory: directory)
    }

    func list(userId: Int) throws -> [OfflineArticleManifest] {
        let directory = root.appending(path: String(userId))
        guard let children = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else { return [] }
        return children.compactMap { try? JSONDecoder.storing.decode(OfflineArticleManifest.self, from: Data(contentsOf: $0.appending(path: "manifest.json"))) }.sorted { $0.downloadedAt > $1.downloadedAt }
    }

    func delete(articleId: Int, userId: Int) throws { try FileManager.default.removeItem(at: root.appending(path: String(userId)).appending(path: String(articleId))) }
    func clear(userId: Int) throws { let target = root.appending(path: String(userId)); if FileManager.default.fileExists(atPath: target.path) { try FileManager.default.removeItem(at: target) } }

    private static func assetName(for url: URL, mimeType: String?) -> String {
        let digest = SHA256.hash(data: Data(url.absoluteString.utf8)).map { String(format: "%02x", $0) }.joined()
        let ext = url.pathExtension.nilIfEmpty ?? mimeType?.split(separator: "/").last.map(String.init) ?? "img"
        return "\(digest.prefix(24)).\(ext.prefix(8))"
    }
    private static func directorySize(_ url: URL) throws -> Int64 {
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .fileSizeKey]
        let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: Array(keys))
        var total: Int64 = 0
        while let file = enumerator?.nextObject() as? URL { let values = try file.resourceValues(forKeys: keys); if values.isRegularFile == true { total += Int64(values.fileSize ?? 0) } }
        return total
    }
}

enum OfflineStoreError: LocalizedError { case missingHTML; var errorDescription: String? { "当前文章没有可下载的 HTML 正文" } }
