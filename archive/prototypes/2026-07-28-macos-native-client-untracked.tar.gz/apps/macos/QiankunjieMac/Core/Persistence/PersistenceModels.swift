import Foundation
import SwiftData

@Model
final class CachedArticleRecord {
    @Attribute(.unique) var cacheKey: String
    var userId: Int
    var view: String
    var articleId: Int
    var payload: Data
    var cachedAt: Date

    init(userId: Int, view: String, articleId: Int, payload: Data, cachedAt: Date = .now) {
        self.cacheKey = "\(userId):\(view):\(articleId)"
        self.userId = userId
        self.view = view
        self.articleId = articleId
        self.payload = payload
        self.cachedAt = cachedAt
    }
}

@Model
final class PendingCollectRecord {
    @Attribute(.unique) var idempotencyKey: UUID
    var userId: Int
    var url: String
    var source: String
    var createdAt: Date
    var lastError: String?

    init(userId: Int, url: String, source: String, idempotencyKey: UUID = UUID(), createdAt: Date = .now) {
        self.idempotencyKey = idempotencyKey
        self.userId = userId
        self.url = url
        self.source = source
        self.createdAt = createdAt
    }
}

@Model
final class ReadingProgressRecord {
    @Attribute(.unique) var cacheKey: String
    var userId: Int
    var articleId: Int
    var progress: Double
    var updatedAt: Date

    init(userId: Int, articleId: Int, progress: Double = 0, updatedAt: Date = .now) {
        self.cacheKey = "\(userId):\(articleId)"
        self.userId = userId
        self.articleId = articleId
        self.progress = progress
        self.updatedAt = updatedAt
    }
}

@Model
final class CachedArticleListRecord {
    @Attribute(.unique) var cacheKey: String
    var userId: Int
    var payload: Data
    var cachedAt: Date

    init(cacheKey: String, userId: Int, payload: Data, cachedAt: Date = .now) {
        self.cacheKey = cacheKey
        self.userId = userId
        self.payload = payload
        self.cachedAt = cachedAt
    }
}
