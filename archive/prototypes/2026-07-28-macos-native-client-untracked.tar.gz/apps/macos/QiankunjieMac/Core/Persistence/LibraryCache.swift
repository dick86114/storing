import Foundation
import SwiftData

struct LibraryCacheScope: Equatable, Sendable {
    let userId: Int
    let view: String
    let query: String
    let order: String
    let category: String?

    init(userId: Int, view: String, query: String, order: String, category: String?) {
        self.userId = userId
        self.view = view
        self.query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        self.order = order
        self.category = category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
    }

    var key: String {
        [String(userId), view, query.lowercased(), order, category?.lowercased() ?? "-"].joined(separator: "|")
    }
}

enum LibraryCacheCodec {
    static func encode(_ response: ArticleListResponse) throws -> Data {
        try JSONEncoder.storing.encode(response)
    }

    static func decode(_ data: Data) throws -> ArticleListResponse {
        try JSONDecoder.storing.decode(ArticleListResponse.self, from: data)
    }
}

@MainActor
struct LibraryCacheStore {
    let context: ModelContext

    func load(scope: LibraryCacheScope) throws -> ArticleListResponse? {
        let records = try context.fetch(FetchDescriptor<CachedArticleListRecord>())
        guard let record = records.first(where: { $0.cacheKey == scope.key && $0.userId == scope.userId }) else { return nil }
        return try LibraryCacheCodec.decode(record.payload)
    }

    func save(_ response: ArticleListResponse, scope: LibraryCacheScope) throws {
        let payload = try LibraryCacheCodec.encode(response)
        let records = try context.fetch(FetchDescriptor<CachedArticleListRecord>())
        if let record = records.first(where: { $0.cacheKey == scope.key && $0.userId == scope.userId }) {
            record.payload = payload
            record.cachedAt = .now
        } else {
            context.insert(CachedArticleListRecord(cacheKey: scope.key, userId: scope.userId, payload: payload))
        }
        try context.save()
    }
}
