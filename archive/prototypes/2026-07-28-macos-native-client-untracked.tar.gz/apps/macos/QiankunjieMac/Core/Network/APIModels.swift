import Foundation

struct NativeUser: Codable, Equatable, Sendable {
    let id: Int
    let username: String
    let role: String
    let status: String
}

struct NativeSessionSummary: Codable, Identifiable, Equatable, Sendable {
    let id: String
    let deviceId: String?
    let deviceName: String?
    let appVersion: String?
    let platform: String?
    let createdAt: String?
    let lastUsedAt: String?
    let expiresAt: String
    let revokedAt: String?

    enum CodingKeys: String, CodingKey {
        case id, platform
        case deviceId = "device_id"
        case deviceName = "device_name"
        case appVersion = "app_version"
        case createdAt = "created_at"
        case lastUsedAt = "last_used_at"
        case expiresAt = "expires_at"
        case revokedAt = "revoked_at"
    }
}

struct NativeAuthResponse: Codable, Sendable {
    let accessToken: String
    let accessTokenExpiresIn: TimeInterval
    let refreshToken: String
    let refreshTokenExpiresIn: TimeInterval
    let user: NativeUser
    let session: NativeSessionSummary

    enum CodingKeys: String, CodingKey {
        case user, session
        case accessToken = "access_token"
        case accessTokenExpiresIn = "access_token_expires_in"
        case refreshToken = "refresh_token"
        case refreshTokenExpiresIn = "refresh_token_expires_in"
    }

    func tokens(now: Date = .now) -> SessionTokens {
        SessionTokens(
            accessToken: accessToken,
            accessTokenExpiresAt: now.addingTimeInterval(accessTokenExpiresIn),
            refreshToken: refreshToken,
            refreshTokenExpiresAt: now.addingTimeInterval(refreshTokenExpiresIn),
            userId: user.id
        )
    }
}

struct ArticleCard: Codable, Identifiable, Hashable, Sendable {
    let id: Int
    let title: String?
    let author: String?
    let source: String?
    let originalUrl: String?
    let publicId: String?
    let coverImage: String?
    let aiSummary: String?
    let aiCategory: String?
    let aiTags: [String]
    let isFavorited: Bool
    let isArchived: Bool
    let isPublished: Bool

    var displayTitle: String { title?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty ?? source?.nilIfEmpty ?? "未命名文章" }
}

struct ArticleDetail: Codable, Identifiable, Hashable, Sendable {
    let id: Int
    let title: String?
    let author: String?
    let source: String?
    let originalUrl: String?
    let publicId: String?
    let coverImage: String?
    let publishTime: String?
    let createdAt: String?
    let aiSummary: String?
    let aiCategory: String?
    let aiTags: [String]
    let isFavorited: Bool
    let isArchived: Bool
    let isPublished: Bool
    let contentHtml: String?
    let contentMd: String?

    var displayTitle: String { title?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty ?? source?.nilIfEmpty ?? "未命名文章" }
}

struct PublicArticleResponse: Codable, Sendable { let article: ArticleDetail }
struct NativeMeResponse: Codable, Sendable { let user: NativeUser }

struct ArticleSource: Codable, Identifiable, Sendable {
    let source: String
    let count: Int
    let latestCreatedAt: String?
    var id: String { source }
}

struct ArticleListResponse: Codable, Sendable {
    let articles: [ArticleCard]
    let total: Int
    let page: Int
    let perPage: Int
    let totalPages: Int
}

struct ArticleCounts: Codable, Equatable, Sendable {
    let inbox: Int
    let favorites: Int
    let archive: Int
    let published: Int
}

struct CollectRequestPayload: Codable, Sendable { let url: String; let source: String }
struct CollectJobResponse: Codable, Sendable { let job: CollectJob }
struct CollectDeleteResponse: Codable, Sendable { let deleted: Bool?; let deletedCount: Int? }
struct NativeSessionsResponse: Codable, Sendable { let sessions: [NativeSessionSummary] }
struct MessageResponse: Codable, Sendable { let message: String?; let revoked: Bool? }
struct CollectJobsResponse: Codable, Sendable { let jobs: [CollectJob]; let total: Int; let hasMore: Bool }

struct CollectJob: Codable, Identifiable, Hashable, Sendable {
    let id: Int
    let url: String
    let normalizedUrl: String
    let status: String
    let stage: String
    let method: String?
    let captureStrategy: String?
    let articleId: Int?
    let title: String?
    let errorSummary: String?
    let errorHint: String?
    var isTerminal: Bool { status == "completed" || status == "failed" }
}

struct APIErrorEnvelope: Codable, Sendable {
    struct Detail: Codable, Sendable { let code: String; let message: String }
    let error: Detail
}

extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}
