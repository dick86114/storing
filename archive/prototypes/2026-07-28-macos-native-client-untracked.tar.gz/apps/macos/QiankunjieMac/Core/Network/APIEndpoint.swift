import Foundation

enum APIEndpoint: Equatable, Sendable {
    static let baseURL = URL(string: "https://storing.idickies.com/api/v1/")!

    case nativeLogin
    case mobileLogin
    case nativeRefresh
    case mobileRefresh
    case nativeLogout
    case mobileLogout
    case nativeSessions
    case mobileSessions
    case revokeSession(String)
    case revokeMobileSession(String)
    case me
    case changePassword
    case counts
    case sources
    case articles(view: String, page: Int, perPage: Int, sort: String?, order: String, category: String?)
    case search(query: String, page: Int, perPage: Int)
    case article(id: Int)
    case publication(publicId: String)
    case articleAction(id: Int, action: String)
    case deleteArticle(id: Int)
    case deleteArticlePermanently(id: Int)
    case nativeCollect
    case mobileCollect
    case collectJobs(limit: Int, offset: Int)
    case mobileCollectJobs(limit: Int, offset: Int)
    case collectJob(id: Int)
    case mobileCollectJob(id: Int)
    case retryCollectJob(id: Int)
    case retryMobileCollectJob(id: Int)
    case deleteCollectJob(id: Int)
    case deleteMobileCollectJob(id: Int)
    case clearCollectJobs
    case clearMobileCollectJobs
    case mcpLimits
    case mcpClients
    case mcpClient(id: Int)
    case mcpRotate(id: Int)
    case mcpLogs
    case adminUsers
    case adminUser(id: Int)
    case adminMcpClients
    case adminMcpLimits
    case adminMcpLogs
    case adminAuditLogs

    var url: URL {
        let path: String
        var query: [URLQueryItem] = []
        switch self {
        case .nativeLogin: path = "native/auth/login"
        case .mobileLogin: path = "mobile/auth/login"
        case .nativeRefresh: path = "native/auth/refresh"
        case .mobileRefresh: path = "mobile/auth/refresh"
        case .nativeLogout: path = "native/auth/logout"
        case .mobileLogout: path = "mobile/auth/logout"
        case .nativeSessions: path = "native/auth/sessions"
        case .mobileSessions: path = "mobile/auth/sessions"
        case .revokeSession(let id): path = "native/auth/sessions/\(id)"
        case .revokeMobileSession(let id): path = "mobile/auth/sessions/\(id)"
        case .me: path = "me"
        case .changePassword: path = "auth/change-password"
        case .counts: path = "counts"
        case .sources: path = "sources"
        case let .articles(view, page, perPage, sort, order, category):
            path = "articles"
            query = [
                URLQueryItem(name: "view", value: view),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "perPage", value: String(perPage)),
                URLQueryItem(name: "order", value: order),
            ]
            if let sort { query.append(URLQueryItem(name: "sort", value: sort)) }
            if let category { query.append(URLQueryItem(name: "category", value: category)) }
        case let .search(searchQuery, page, perPage):
            path = "search"
            query = [URLQueryItem(name: "q", value: searchQuery), URLQueryItem(name: "page", value: String(page)), URLQueryItem(name: "perPage", value: String(perPage))]
        case .publication(let publicId): path = "publications/\(publicId)"
        case .article(let id):
            path = "articles/\(id)"
            query = [URLQueryItem(name: "format", value: "html"), URLQueryItem(name: "htmlVariant", value: "mobile")]
        case let .articleAction(id, action): path = "articles/\(id)/\(action)"
        case .deleteArticle(let id): path = "articles/\(id)"
        case .deleteArticlePermanently(let id): path = "articles/\(id)/permanent"
        case .nativeCollect: path = "native/collect"
        case .mobileCollect: path = "mobile/collect"
        case let .collectJobs(limit, offset), let .mobileCollectJobs(limit, offset):
            path = self == .collectJobs(limit: limit, offset: offset) ? "native/collect/jobs" : "mobile/collect/jobs"
            query = [URLQueryItem(name: "limit", value: String(limit)), URLQueryItem(name: "offset", value: String(offset))]
        case .collectJob(let id): path = "native/collect/jobs/\(id)"
        case .mobileCollectJob(let id): path = "mobile/collect/jobs/\(id)"
        case .retryCollectJob(let id): path = "native/collect/jobs/\(id)/retry"
        case .retryMobileCollectJob(let id): path = "mobile/collect/jobs/\(id)/retry"
        case .deleteCollectJob(let id): path = "native/collect/jobs/\(id)"
        case .deleteMobileCollectJob(let id): path = "mobile/collect/jobs/\(id)"
        case .clearCollectJobs: path = "native/collect/jobs"
        case .clearMobileCollectJobs: path = "mobile/collect/jobs"
        case .mcpLimits: path = "mcp/me/limits"
        case .mcpClients: path = "mcp/me/clients"
        case .mcpClient(let id): path = "mcp/me/clients/\(id)"
        case .mcpRotate(let id): path = "mcp/me/clients/\(id)/rotate-key"
        case .mcpLogs: path = "mcp/me/request-logs"
        case .adminUsers: path = "admin/users"
        case .adminUser(let id): path = "admin/users/\(id)"
        case .adminMcpClients: path = "admin/mcp/clients"
        case .adminMcpLimits: path = "admin/mcp/default-limits"
        case .adminMcpLogs: path = "admin/mcp/request-logs"
        case .adminAuditLogs: path = "admin/audit-logs"
        }
        var components = URLComponents(url: Self.baseURL.appending(path: path), resolvingAgainstBaseURL: false)!
        if !query.isEmpty { components.queryItems = query }
        return components.url!
    }
}


extension APIEndpoint {
    var legacyMobileFallback: APIEndpoint? {
        switch self {
        case .nativeLogin: .mobileLogin
        case .nativeRefresh: .mobileRefresh
        case .nativeLogout: .mobileLogout
        case .nativeSessions: .mobileSessions
        case .revokeSession(let id): .revokeMobileSession(id)
        case .nativeCollect: .mobileCollect
        case let .collectJobs(limit, offset): .mobileCollectJobs(limit: limit, offset: offset)
        case .collectJob(let id): .mobileCollectJob(id: id)
        case .retryCollectJob(let id): .retryMobileCollectJob(id: id)
        case .deleteCollectJob(let id): .deleteMobileCollectJob(id: id)
        case .clearCollectJobs: .clearMobileCollectJobs
        default: nil
        }
    }
}

extension JSONDecoder {
    static var storing: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}

extension JSONEncoder {
    static var storing: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}
