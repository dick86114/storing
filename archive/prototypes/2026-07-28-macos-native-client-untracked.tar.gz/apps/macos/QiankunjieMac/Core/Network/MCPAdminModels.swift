import Foundation

struct MCPPlatformLimits: Codable, Sendable {
    let rateLimitPerMinute: Int
    let rateLimitPerDay: Int
    let concurrentCollectLimit: Int
    enum CodingKeys: String, CodingKey { case rateLimitPerMinute = "rate_limit_per_minute", rateLimitPerDay = "rate_limit_per_day", concurrentCollectLimit = "concurrent_collect_limit" }
}
struct MCPClient: Codable, Identifiable, Hashable, Sendable {
    let id: Int; let name: String; let ownerUserId: Int; let ownerUsername: String?; let scopes: [String]; let enabled: Bool
    let rateLimitPerMinute: Int?; let rateLimitPerDay: Int?; let concurrentCollectLimit: Int?; let defaultSaveToInbox: Bool
    let createdAt: String?; let updatedAt: String?; let lastUsedAt: String?
    enum CodingKeys: String, CodingKey {
        case id, name, scopes, enabled
        case ownerUserId = "owner_user_id", ownerUsername = "owner_username"
        case rateLimitPerMinute = "rate_limit_per_minute", rateLimitPerDay = "rate_limit_per_day", concurrentCollectLimit = "concurrent_collect_limit"
        case defaultSaveToInbox = "default_save_to_inbox", createdAt = "created_at", updatedAt = "updated_at", lastUsedAt = "last_used_at"
    }
}
struct MCPClientsResponse: Codable, Sendable { let clients: [MCPClient] }
struct MCPClientResponse: Codable, Sendable { let client: MCPClient }
struct MCPKeyResponse: Codable, Sendable { let client: MCPClient; let apiKey: String; enum CodingKeys: String, CodingKey { case client; case apiKey = "api_key" } }
struct MCPRequestLog: Codable, Identifiable, Sendable {
    let id: Int; let clientId: Int?; let toolName: String; let url: String?; let status: String; let errorCode: String?; let durationMs: Int?; let createdAt: String?
    enum CodingKeys: String, CodingKey { case id, url, status; case clientId = "client_id", toolName = "tool_name", errorCode = "error_code", durationMs = "duration_ms", createdAt = "created_at" }
}
struct MCPLogsResponse: Codable, Sendable { let logs: [MCPRequestLog] }
struct MCPCreateRequest: Codable, Sendable { let name: String; let scopes: [String]; let enabled: Bool; let defaultSaveToInbox: Bool; enum CodingKeys: String, CodingKey { case name, scopes, enabled; case defaultSaveToInbox = "default_save_to_inbox" } }
struct MCPUpdateRequest: Codable, Sendable { let enabled: Bool?; let scopes: [String]?; let defaultSaveToInbox: Bool?; enum CodingKeys: String, CodingKey { case enabled, scopes; case defaultSaveToInbox = "default_save_to_inbox" } }
struct MCPDeleteResponse: Codable, Sendable { let revoked: Bool }

struct AdminUser: Codable, Identifiable, Sendable {
    let id: Int; let username: String; let role: String; let status: String; let createdAt: String?; let lastLoginAt: String?
    let mcpClientCount: Int; let inboxCount: Int; let archiveCount: Int; let favoriteCount: Int
    enum CodingKeys: String, CodingKey { case id, username, role, status; case createdAt = "created_at", lastLoginAt = "last_login_at", mcpClientCount = "mcp_client_count", inboxCount = "inbox_count", archiveCount = "archive_count", favoriteCount = "favorite_count" }
}
struct AdminUsersResponse: Codable, Sendable { let users: [AdminUser] }
struct AdminUserResponse: Codable, Sendable { let user: AdminUser }
struct AdminUserMutation: Codable, Sendable { let username: String?; let password: String?; let role: String?; let status: String? }
struct AdminAuditLog: Codable, Identifiable, Sendable {
    let id: Int; let actorUsername: String?; let targetUsername: String?; let articleTitle: String?; let action: String; let createdAt: String?
    enum CodingKeys: String, CodingKey { case id, action; case actorUsername = "actor_username", targetUsername = "target_username", articleTitle = "article_title", createdAt = "created_at" }
}
struct AdminAuditLogsResponse: Codable, Sendable { let total: Int; let logs: [AdminAuditLog] }
