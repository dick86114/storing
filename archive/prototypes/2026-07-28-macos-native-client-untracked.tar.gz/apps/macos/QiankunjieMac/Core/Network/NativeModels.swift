import Foundation

struct NativeDevicePayload: Codable, Equatable, Sendable {
    let deviceId: UUID
    let deviceName: String
    let appVersion: String
    let platform = "macos"

    enum CodingKeys: String, CodingKey {
        case deviceId, deviceName, appVersion, platform
    }
}
