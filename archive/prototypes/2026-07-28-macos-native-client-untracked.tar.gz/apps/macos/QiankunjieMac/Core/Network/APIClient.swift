import Foundation

enum HTTPMethod: String, Sendable { case get = "GET", post = "POST", patch = "PATCH", delete = "DELETE" }

enum APIClientError: LocalizedError, Equatable {
    case authenticationRequired
    case invalidResponse
    case server(code: String, message: String, status: Int)

    var errorDescription: String? {
        switch self {
        case .authenticationRequired: "登录已失效，请重新登录"
        case .invalidResponse: "服务器响应格式无效"
        case .server(_, let message, _): message
        }
    }
}

actor APIClient {
    static let shared = APIClient()

    private let urlSession: URLSession
    private let sessionStore: KeychainSessionStore
    private let deviceProvider: DeviceIdentityProvider
    private var tokens: SessionTokens?
    private var refreshTask: Task<SessionTokens, Error>?
    private var legacyMobileAPI = false

    init(
        urlSession: URLSession = .shared,
        sessionStore: KeychainSessionStore = KeychainSessionStore(),
        deviceProvider: DeviceIdentityProvider = DeviceIdentityProvider()
    ) {
        self.urlSession = urlSession
        self.sessionStore = sessionStore
        self.deviceProvider = deviceProvider
        self.tokens = sessionStore.read()
    }

    func restoredUserId() -> Int? {
        guard let tokens, tokens.hasUsableRefreshToken() else { return nil }
        return tokens.userId
    }

    func login(username: String, password: String) async throws -> NativeAuthResponse {
        struct Body: Encodable { let username: String; let password: String; let device: NativeDevicePayload }
        let response: NativeAuthResponse = try await send(
            .nativeLogin,
            method: .post,
            body: Body(username: username, password: password, device: deviceProvider.current()),
            authenticated: false
        )
        let next = response.tokens()
        try sessionStore.write(next)
        tokens = next
        return response
    }

    func logout() async {
        if let refreshToken = tokens?.refreshToken {
            struct Body: Encodable { let refresh_token: String }
            let _: EmptyResponse? = try? await send(.nativeLogout, method: .post, body: Body(refresh_token: refreshToken), authenticated: false)
        }
        tokens = nil
        sessionStore.clear()
    }

    func request<T: Decodable & Sendable>(_ endpoint: APIEndpoint, method: HTTPMethod = .get, authenticated: Bool = true) async throws -> T {
        try await send(endpoint, method: method, bodyData: nil, authenticated: authenticated)
    }

    func request<T: Decodable & Sendable, Body: Encodable & Sendable>(
        _ endpoint: APIEndpoint,
        method: HTTPMethod = .post,
        body: Body,
        authenticated: Bool = true
    ) async throws -> T {
        try await send(endpoint, method: method, bodyData: try JSONEncoder.storing.encode(body), authenticated: authenticated)
    }

    func submitCollect(url: URL, source: CollectEntrySource) async throws -> CollectJobResponse {
        let endpoint: APIEndpoint = legacyMobileAPI ? .mobileCollect : .nativeCollect
        let sourceValue = legacyMobileAPI ? source.legacyMobileValue : source.rawValue
        return try await send(endpoint, method: .post, body: CollectRequestPayload(url: url.absoluteString, source: sourceValue), authenticated: true)
    }

    private func send<T: Decodable & Sendable, Body: Encodable & Sendable>(
        _ endpoint: APIEndpoint,
        method: HTTPMethod,
        body: Body,
        authenticated: Bool
    ) async throws -> T {
        try await send(endpoint, method: method, bodyData: try JSONEncoder.storing.encode(body), authenticated: authenticated)
    }

    private func send<T: Decodable & Sendable>(
        _ endpoint: APIEndpoint,
        method: HTTPMethod,
        bodyData: Data?,
        authenticated: Bool
    ) async throws -> T {
        if authenticated { try await ensureAccessToken() }
        let initialEndpoint = legacyMobileAPI ? (endpoint.legacyMobileFallback ?? endpoint) : endpoint
        var response = try await perform(initialEndpoint, method: method, bodyData: bodyData, bearer: authenticated ? tokens?.accessToken : nil)
        if response.status == 404, !legacyMobileAPI, let fallback = endpoint.legacyMobileFallback {
            legacyMobileAPI = true
            response = try await perform(fallback, method: method, bodyData: bodyData, bearer: authenticated ? tokens?.accessToken : nil)
        }
        if response.status == 401, authenticated {
            _ = try await refresh()
            let retryEndpoint = legacyMobileAPI ? (endpoint.legacyMobileFallback ?? endpoint) : endpoint
            response = try await perform(retryEndpoint, method: method, bodyData: bodyData, bearer: tokens?.accessToken)
        }
        guard (200..<300).contains(response.status) else {
            if response.status == 401 { throw APIClientError.authenticationRequired }
            if let envelope = try? JSONDecoder.storing.decode(APIErrorEnvelope.self, from: response.data) {
                throw APIClientError.server(code: envelope.error.code, message: envelope.error.message, status: response.status)
            }
            throw APIClientError.server(code: "HTTP_\(response.status)", message: "请求失败（HTTP \(response.status)）", status: response.status)
        }
        if T.self == EmptyResponse.self, response.data.isEmpty {
            return EmptyResponse() as! T
        }
        guard let decoded = try? JSONDecoder.storing.decode(T.self, from: response.data) else { throw APIClientError.invalidResponse }
        return decoded
    }

    private func perform(_ endpoint: APIEndpoint, method: HTTPMethod, bodyData: Data?, bearer: String?) async throws -> (data: Data, status: Int) {
        var request = URLRequest(url: endpoint.url)
        request.httpMethod = method.rawValue
        request.timeoutInterval = 45
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let bodyData {
            request.httpBody = bodyData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        if let bearer { request.setValue("Bearer \(bearer)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await urlSession.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIClientError.invalidResponse }
        return (data, http.statusCode)
    }

    private func ensureAccessToken() async throws {
        guard let current = tokens, current.hasUsableRefreshToken() else { throw APIClientError.authenticationRequired }
        if !current.hasUsableAccessToken() { _ = try await refresh() }
    }

    private func refresh() async throws -> SessionTokens {
        if let refreshTask { return try await refreshTask.value }
        guard let current = tokens, current.hasUsableRefreshToken() else { throw APIClientError.authenticationRequired }
        let task = Task<SessionTokens, Error> {
            struct Body: Encodable { let refresh_token: String; let device: NativeDevicePayload }
            let response: NativeAuthResponse = try await self.send(
                .nativeRefresh,
                method: .post,
                bodyData: try JSONEncoder.storing.encode(Body(refresh_token: current.refreshToken, device: self.deviceProvider.current())),
                authenticated: false
            )
            return response.tokens()
        }
        refreshTask = task
        defer { refreshTask = nil }
        do {
            let next = try await task.value
            try sessionStore.write(next)
            tokens = next
            return next
        } catch {
            tokens = nil
            sessionStore.clear()
            throw error
        }
    }
}

struct EmptyResponse: Codable, Sendable {}
struct DiscardResponse: Decodable, Sendable {
    init(from decoder: Decoder) throws { }
}
