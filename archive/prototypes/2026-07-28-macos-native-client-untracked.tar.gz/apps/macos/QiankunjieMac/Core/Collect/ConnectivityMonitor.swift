import Foundation
import Network

final class ConnectivityMonitor: @unchecked Sendable {
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "com.idickies.storing.macos.connectivity")
    init(onReachable: @escaping @Sendable () -> Void) {
        monitor.pathUpdateHandler = { path in if path.status == .satisfied { onReachable() } }
        monitor.start(queue: queue)
    }
    deinit { monitor.cancel() }
}
