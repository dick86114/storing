import Foundation

enum CollectEntrySource: String, Codable, Sendable {
    case manual = "macos"
    case share = "macos_share"
    case browser = "macos_browser"

    var legacyMobileValue: String {
        self == .manual ? "android" : "android_share"
    }
}

struct IncomingCollectRequest: Equatable, Sendable {
    let urls: [URL]
    let title: String?
    let source: CollectEntrySource
}

enum IncomingCollectDeepLinkTarget: Equatable, Sendable {
    case inline(IncomingCollectRequest)
    case sharedPayload(UUID)
}

enum IncomingCollectError: LocalizedError, Equatable {
    case invalidDeepLink
    case invalidSharedPayload
    case noWebURL

    var errorDescription: String? {
        switch self {
        case .invalidDeepLink: "采集链接无效"
        case .invalidSharedPayload: "分享内容已过期或无法读取"
        case .noWebURL: "没有找到有效的网页链接"
        }
    }
}

enum IncomingCollectRouter {
    static func extractURLs(from text: String) -> [URL] {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else {
            return []
        }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        var seen = Set<String>()
        return detector.matches(in: text, options: [], range: range).compactMap { match in
            guard let url = match.url,
                  let scheme = url.scheme?.lowercased(),
                  scheme == "http" || scheme == "https" else { return nil }
            let normalized = url.absoluteString
            guard seen.insert(normalized).inserted else { return nil }
            return url
        }
    }

    static func extractURLs(from values: [String]) -> [URL] {
        var seen = Set<String>()
        return values.flatMap(extractURLs).filter { seen.insert($0.absoluteString).inserted }
    }

    static func parseDeepLinkTarget(_ url: URL) throws -> IncomingCollectDeepLinkTarget {
        guard url.scheme?.lowercased() == "qiankunjie", url.host?.lowercased() == "collect",
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            throw IncomingCollectError.invalidDeepLink
        }
        let items = components.queryItems ?? []
        if let payloadValue = items.first(where: { $0.name == "payload" })?.value {
            guard let id = UUID(uuidString: payloadValue) else { throw IncomingCollectError.invalidSharedPayload }
            return .sharedPayload(id)
        }
        return .inline(try parseInlineDeepLink(items))
    }

    static func parseDeepLink(_ url: URL) throws -> IncomingCollectRequest {
        switch try parseDeepLinkTarget(url) {
        case let .inline(request): request
        case .sharedPayload: throw IncomingCollectError.invalidSharedPayload
        }
    }

    private static func parseInlineDeepLink(_ items: [URLQueryItem]) throws -> IncomingCollectRequest {
        let rawValues = items.filter { $0.name == "url" }.compactMap(\.value)
        let urls = extractURLs(from: rawValues)
        guard !urls.isEmpty else { throw IncomingCollectError.noWebURL }
        let title = items.first(where: { $0.name == "title" })?.value?.trimmingCharacters(in: .whitespacesAndNewlines)
        let sourceValue = items.first(where: { $0.name == "source" })?.value
        let source: CollectEntrySource = sourceValue == "browser" ? .browser : sourceValue == "share" ? .share : .manual
        return IncomingCollectRequest(urls: urls, title: title?.isEmpty == true ? nil : title, source: source)
    }
}

extension SharedCollectPayload {
    var collectRequest: IncomingCollectRequest {
        IncomingCollectRequest(urls: IncomingCollectRouter.extractURLs(from: values), title: title, source: .share)
    }
}
