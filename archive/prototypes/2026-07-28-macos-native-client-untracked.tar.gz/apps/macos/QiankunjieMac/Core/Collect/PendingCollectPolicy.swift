import Foundation

enum PendingCollectPolicy {
    static func shouldQueue(_ error: Error) -> Bool {
        if let urlError = error as? URLError {
            return [.notConnectedToInternet, .networkConnectionLost, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed, .timedOut].contains(urlError.code)
        }
        let nsError = error as NSError
        guard nsError.domain == NSURLErrorDomain else { return false }
        return shouldQueue(URLError(URLError.Code(rawValue: nsError.code)))
    }
}
