import Foundation

struct SessionTokens: Codable, Equatable, Sendable {
    let accessToken: String
    let accessTokenExpiresAt: Date
    let refreshToken: String
    let refreshTokenExpiresAt: Date
    let userId: Int

    func hasUsableAccessToken(at now: Date = .now, refreshLeeway: TimeInterval = 60) -> Bool {
        accessTokenExpiresAt.timeIntervalSince(now) > refreshLeeway
    }

    func hasUsableRefreshToken(at now: Date = .now) -> Bool {
        refreshTokenExpiresAt > now
    }
}
