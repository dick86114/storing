import Foundation

struct DeviceIdentityProvider: Sendable {
    private let key = "qiankunjie.native.device-id"

    func current() -> NativeDevicePayload {
        let defaults = UserDefaults.standard
        let id: UUID
        if let raw = defaults.string(forKey: key), let saved = UUID(uuidString: raw) {
            id = saved
        } else {
            id = UUID()
            defaults.set(id.uuidString, forKey: key)
        }
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.1.0"
        return NativeDevicePayload(deviceId: id, deviceName: Host.current().localizedName ?? "Mac", appVersion: version)
    }
}
