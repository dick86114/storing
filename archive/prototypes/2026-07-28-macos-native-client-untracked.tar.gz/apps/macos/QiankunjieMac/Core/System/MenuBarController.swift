import AppKit
import Foundation

enum MenuBarTaskSummary {
    static func title(activeCount: Int) -> String {
        activeCount == 0 ? "没有进行中的任务" : "进行中任务：\(activeCount)"
    }
}

@MainActor
final class MenuBarController: NSObject, NSMenuDelegate {
    private var statusItem: NSStatusItem?
    private var jobs: [CollectJob] = []
    private var onQuickCollect: (() -> Void)?
    private var onOpenMain: (() -> Void)?
    private var onOpenTasks: (() -> Void)?

    func setEnabled(
        _ enabled: Bool,
        jobs: [CollectJob],
        onQuickCollect: @escaping () -> Void,
        onOpenMain: @escaping () -> Void,
        onOpenTasks: @escaping () -> Void
    ) {
        self.jobs = jobs
        self.onQuickCollect = onQuickCollect
        self.onOpenMain = onOpenMain
        self.onOpenTasks = onOpenTasks
        if enabled {
            if statusItem == nil { createStatusItem() }
            rebuildMenu()
        } else if let statusItem {
            NSStatusBar.system.removeStatusItem(statusItem)
            self.statusItem = nil
        }
    }

    func update(jobs: [CollectJob]) {
        self.jobs = jobs
        if statusItem != nil { rebuildMenu() }
    }

    func menuWillOpen(_ menu: NSMenu) {
        rebuildMenu()
    }

    private func createStatusItem() {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        let image = NSImage(systemSymbolName: "circle.hexagongrid.fill", accessibilityDescription: "乾坤戒")
        image?.isTemplate = true
        item.button?.image = image
        item.button?.toolTip = "乾坤戒"
        statusItem = item
    }

    private func rebuildMenu() {
        let menu = NSMenu(title: "乾坤戒")
        menu.delegate = self
        menu.addItem(item("快速采集…", action: #selector(quickCollect), keyEquivalent: "s", modifiers: [.command, .option]))
        menu.addItem(item("打开主窗口", action: #selector(openMain)))
        menu.addItem(.separator())

        let activeCount = jobs.filter { !$0.isTerminal }.count
        let summary = NSMenuItem(title: MenuBarTaskSummary.title(activeCount: activeCount), action: #selector(openTasks), keyEquivalent: "")
        summary.target = self
        summary.image = NSImage(systemSymbolName: activeCount == 0 ? "checkmark.circle" : "clock.arrow.circlepath", accessibilityDescription: nil)
        menu.addItem(summary)
        for job in jobs.prefix(3) {
            let title = job.title?.nilIfEmpty ?? URL(string: job.url)?.host ?? job.url
            let recent = NSMenuItem(title: "  \(title) · \(job.status)", action: #selector(openTasks), keyEquivalent: "")
            recent.target = self
            recent.toolTip = job.url
            menu.addItem(recent)
        }

        menu.addItem(.separator())
        menu.addItem(item("退出乾坤戒", action: #selector(terminate)))
        statusItem?.menu = menu
    }

    private func item(
        _ title: String,
        action: Selector,
        keyEquivalent: String = "",
        modifiers: NSEvent.ModifierFlags = []
    ) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: keyEquivalent)
        item.target = self
        item.keyEquivalentModifierMask = modifiers
        return item
    }

    @objc private func quickCollect() { onQuickCollect?() }
    @objc private func openMain() { onOpenMain?() }
    @objc private func openTasks() { onOpenTasks?() }
    @objc private func terminate() { NSApp.terminate(nil) }
}
