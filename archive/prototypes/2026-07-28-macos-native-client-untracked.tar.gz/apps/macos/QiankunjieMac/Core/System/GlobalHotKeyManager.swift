import AppKit
import Carbon.HIToolbox
import Foundation

struct GlobalShortcutDescriptor: Codable, Equatable, Identifiable, Sendable {
    let id: String
    let displayName: String
    let keyCode: UInt32
    let carbonModifiers: UInt32

    static let defaultPreset = GlobalShortcutDescriptor(
        id: "option-command-s",
        displayName: "⌥⌘S",
        keyCode: UInt32(kVK_ANSI_S),
        carbonModifiers: UInt32(cmdKey | optionKey)
    )
    static let presets: [GlobalShortcutDescriptor] = [
        defaultPreset,
        GlobalShortcutDescriptor(id: "shift-command-s", displayName: "⇧⌘S", keyCode: UInt32(kVK_ANSI_S), carbonModifiers: UInt32(cmdKey | shiftKey)),
        GlobalShortcutDescriptor(id: "control-option-s", displayName: "⌃⌥S", keyCode: UInt32(kVK_ANSI_S), carbonModifiers: UInt32(controlKey | optionKey)),
    ]

    static func preset(id: String?) -> GlobalShortcutDescriptor {
        presets.first(where: { $0.id == id }) ?? defaultPreset
    }
}

final class GlobalHotKeyManager: @unchecked Sendable {
    private var hotKeyRef: EventHotKeyRef?
    private var handlerRef: EventHandlerRef?
    private var action: (@MainActor () -> Void)?

    func register(_ descriptor: GlobalShortcutDescriptor, action: @escaping @MainActor () -> Void) {
        unregister()
        self.action = action

        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(
            GetApplicationEventTarget(),
            { _, _, userData in
                guard let userData else { return noErr }
                let manager = Unmanaged<GlobalHotKeyManager>.fromOpaque(userData).takeUnretainedValue()
                Task { @MainActor in manager.action?() }
                return noErr
            },
            1,
            &eventType,
            Unmanaged.passUnretained(self).toOpaque(),
            &handlerRef
        )

        let signature = OSType(UInt32(ascii: "Q") << 24 | UInt32(ascii: "K") << 16 | UInt32(ascii: "J") << 8 | UInt32(ascii: "K"))
        let eventID = EventHotKeyID(signature: signature, id: 1)
        RegisterEventHotKey(
            descriptor.keyCode,
            descriptor.carbonModifiers,
            eventID,
            GetApplicationEventTarget(),
            0,
            &hotKeyRef
        )
    }

    func unregister() {
        if let hotKeyRef { UnregisterEventHotKey(hotKeyRef) }
        if let handlerRef { RemoveEventHandler(handlerRef) }
        hotKeyRef = nil
        handlerRef = nil
        action = nil
    }

    deinit { unregister() }
}

@MainActor
final class SystemActionRouter {
    static let shared = SystemActionRouter()
    var openMainWindow: (() -> Void)?

    func revealMainWindow() {
        openMainWindow?()
        NSApp.activate(ignoringOtherApps: true)
    }
}

private extension UInt32 {
    init(ascii character: Character) {
        self = UInt32(character.asciiValue ?? 0)
    }
}
