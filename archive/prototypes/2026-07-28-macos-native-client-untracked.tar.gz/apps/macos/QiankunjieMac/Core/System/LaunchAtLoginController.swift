import Foundation
import ServiceManagement

enum LaunchAtLoginStatus: Equatable, Sendable {
    case notRegistered
    case enabled
    case requiresApproval
    case notFound

    var isPresentedAsEnabled: Bool {
        self == .enabled || self == .requiresApproval
    }

    init(_ status: SMAppService.Status) {
        switch status {
        case .notRegistered: self = .notRegistered
        case .enabled: self = .enabled
        case .requiresApproval: self = .requiresApproval
        case .notFound: self = .notFound
        @unknown default: self = .notFound
        }
    }
}

@MainActor
enum LaunchAtLoginController {
    static var status: LaunchAtLoginStatus { LaunchAtLoginStatus(SMAppService.mainApp.status) }

    static func setEnabled(_ enabled: Bool) throws -> LaunchAtLoginStatus {
        let service = SMAppService.mainApp
        if enabled {
            if service.status == .notRegistered || service.status == .notFound {
                try service.register()
            }
        } else if service.status != .notRegistered {
            try service.unregister()
        }
        return LaunchAtLoginStatus(service.status)
    }
}
