import SwiftUI

struct SidebarView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image("BrandLogo")
                    .resizable().scaledToFit().frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .shadow(color: QKColor.gold.opacity(0.28), radius: 6, y: 2)
                VStack(alignment: .leading, spacing: 1) {
                    Text("乾坤戒").font(.headline).fontDesign(.serif)
                    Text("STORING").font(.caption2).tracking(1.6).foregroundStyle(.secondary)
                }
                Spacer()
            }.padding(18)

            List(selection: Binding(get: { model.destination }, set: { if let value = $0 { model.select(value) } })) {
                Section {
                    sidebarRow(.inbox, count: model.counts.inbox)
                    sidebarRow(.favorites, count: model.counts.favorites)
                    sidebarRow(.archive, count: model.counts.archive)
                    sidebarRow(.published, count: model.counts.published)
                }
                Section {
                    sidebarRow(.collect)
                    sidebarRow(.tasks, count: model.jobs.filter { !$0.isTerminal }.count)
                    sidebarRow(.mcp)
                    if model.isAdmin { sidebarRow(.admin) }
                }
                Section { sidebarRow(.settings) }
            }
            .listStyle(.sidebar)
            .scrollContentBackground(.hidden)

            HStack(spacing: 10) {
                Circle().fill(QKColor.gold.opacity(0.25)).frame(width: 34, height: 34).overlay(Text(String(model.user?.username.prefix(1) ?? "游")).fontWeight(.bold))
                VStack(alignment: .leading, spacing: 2) {
                    Text(model.user?.username ?? "游客").font(.subheadline).fontWeight(.semibold)
                    Text(model.user == nil ? "浏览公开文章" : (model.user?.role == "admin" ? "管理员" : "知识工作者")).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
            }.padding(14).background((colorScheme == .dark ? Color.white : Color.black).opacity(0.035))
        }
        .background(colorScheme == .dark ? QKColor.bamboo : QKColor.paperMuted)
    }

    private func sidebarRow(_ destination: AppModel.Destination, count: Int? = nil) -> some View {
        Label {
            HStack { Text(destination.title); Spacer(); if let count, count > 0 { Text("\(count)").font(.caption).foregroundStyle(.secondary) } }
        } icon: { Image(systemName: destination.symbol) }
        .tag(destination)
        .accessibilityLabel(count.map { "\(destination.title)，\($0) 篇" } ?? destination.title)
    }
}
