import SwiftUI

struct RootView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.modelContext) private var modelContext
    @Environment(\.openWindow) private var openWindow
    @AppStorage("appearance") private var appearance = AppAppearance.system.rawValue

    var body: some View {
        @Bindable var model = model
        Group {
            if model.focusReading, let detail = model.articleDetail {
                ReaderView(article: detail, offlineFile: model.articleOfflineFile, focused: true)
                    .overlay(alignment: .topLeading) {
                        Button { model.focusReading = false } label: { Label("退出专注", systemImage: "rectangle.split.3x1") }
                            .buttonStyle(.borderedProminent).tint(QKColor.gold).padding()
                    }
            } else {
                NavigationSplitView {
                    SidebarView()
                        .navigationSplitViewColumnWidth(min: 190, ideal: 220, max: 260)
                } detail: {
                    destinationContent
                }
                .navigationSplitViewStyle(.balanced)
                .transition(.opacity.combined(with: .scale(scale: 0.995)))
            }
        }
        .animation(.smooth(duration: 0.32), value: model.destination)
        .animation(.smooth(duration: 0.34), value: model.selectedArticle?.id)
        .overlay {
            if model.isLocked { BiometricLockView().transition(.opacity.combined(with: .scale(scale: 1.02))).zIndex(100) }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didResignActiveNotification)) { _ in
            if UserDefaults.standard.bool(forKey: "security.touchID"), model.user != nil { model.isLocked = true }
        }
        .overlay(alignment: .topTrailing) {
            HStack(spacing: 7) {
                Image(systemName: "sparkle").font(.caption2)
                Image(systemName: "sparkles").font(.caption)
            }
            .foregroundStyle(QKColor.gold.opacity(0.28))
            .padding(18)
            .allowsHitTesting(false)
        }
        .background(colorScheme == .dark ? QKColor.ink : QKColor.paper)
        .preferredColorScheme(AppAppearance(storedValue: appearance).colorScheme)
        .onAppear {
            model.attachPersistence(modelContext)
            SystemActionRouter.shared.openMainWindow = { openWindow(id: "main") }
        }
        .tint(QKColor.gold)
        .sheet(isPresented: $model.showsLogin) { LoginView() }
        .sheet(isPresented: $model.showsCollect) { CollectConfirmationView() }
        .alert("暂时无法完成操作", isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) {
            Button("关闭", role: .cancel) { model.errorMessage = nil }
        } message: { Text(model.errorMessage ?? "未知错误") }
    }

    @ViewBuilder
    private var destinationContent: some View {
        switch model.destination {
        case .inbox, .favorites, .archive, .published:
            GeometryReader { geometry in
                HStack(spacing: 0) {
                    LibraryView()
                        .frame(width: model.selectedArticle == nil ? geometry.size.width : min(max(340, geometry.size.width * 0.34), 430))
                        .frame(maxHeight: .infinity)
                    if let detail = model.articleDetail {
                        Divider()
                        ReaderView(article: detail, offlineFile: model.articleOfflineFile, focused: false)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else if model.isLoadingDetail {
                        Divider()
                        ProgressView("正在打开文章…").frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                }
            }
        case .collect: CollectWorkspaceView()
        case .tasks: CollectJobsView()
        case .mcp: MCPWorkspaceView()
        case .admin: AdminWorkspaceView()
        case .settings: SettingsWorkspaceView()
        }
    }
}
