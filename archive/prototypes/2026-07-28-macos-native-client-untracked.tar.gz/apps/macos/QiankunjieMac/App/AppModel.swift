import AppKit
import Foundation
import Observation
import SwiftData

@MainActor
@Observable
final class AppModel {
    enum Destination: String, CaseIterable, Identifiable {
        case inbox, favorites, archive, published, collect, tasks, mcp, admin, settings
        var id: String { rawValue }
        var title: String {
            switch self {
            case .inbox: "收件箱"; case .favorites: "收藏"; case .archive: "归档"; case .published: "发布"
            case .collect: "采集"; case .tasks: "采集任务"; case .mcp: "MCP 设置"; case .admin: "管理员后台"; case .settings: "设置"
            }
        }
        var symbol: String {
            switch self {
            case .inbox: "tray"; case .favorites: "heart"; case .archive: "archivebox"; case .published: "globe.asia.australia"
            case .collect: "plus.circle"; case .tasks: "clock.arrow.circlepath"; case .mcp: "externaldrive.connected.to.line.below"
            case .admin: "shield"; case .settings: "gearshape"
            }
        }
        var requiresLogin: Bool { self != .published }
    }

    enum PresentationMode: String, CaseIterable { case list = "列表", grid = "瀑布流", card = "卡片" }

    let api: APIClient
    let offlineStore: OfflineArticleStore
    private var modelContext: ModelContext?
    private var connectivityMonitor: ConnectivityMonitor?
    private let globalHotKeyManager = GlobalHotKeyManager()
    private let menuBarController = MenuBarController()
    var destination: Destination = .published
    var user: NativeUser?
    var counts = ArticleCounts(inbox: 0, favorites: 0, archive: 0, published: 0)
    var articles: [ArticleCard] = []
    var selectedArticle: ArticleCard?
    var articleDetail: ArticleDetail?
    var articleOfflineFile: URL?
    var isDownloadingOffline = false
    var jobs: [CollectJob] = []
    var isLoading = false
    var isLoadingDetail = false
    var errorMessage: String?
    var searchQuery = ""
    var sortOrder = "desc"
    var presentationMode: PresentationMode = .card
    var pagination = LibraryPagination()
    var archiveSources: [ArticleSource] = []
    var selectedCategory: String?
    var isLoadingMore = false
    var focusReading = false
    var showsLogin = false
    var showsCollect = false
    var showsTasks = false
    var isOfflineCache = false
    var isLocked = false
    var isUILab = ProcessInfo.processInfo.arguments.contains("--ui-lab")

    init(api: APIClient = .shared, offlineStore: OfflineArticleStore = .shared) { self.api = api; self.offlineStore = offlineStore }


    func attachPersistence(_ context: ModelContext) {
        guard !isUILab, modelContext == nil else { return }
        modelContext = context
        connectivityMonitor = ConnectivityMonitor { [weak self] in
            Task { @MainActor in await self?.retryPendingCollects() }
        }
        Task { await reload(); await retryPendingCollects() }
    }

    var isAdmin: Bool { user?.role == "admin" }
    var navigationDestinations: [Destination] { Destination.allCases.filter { $0 != .admin || isAdmin } }

    func start() async {
        configureGlobalShortcut(id: UserDefaults.standard.string(forKey: "globalShortcut.id"))
        let menuBarEnabled = UserDefaults.standard.object(forKey: "menubar.enabled") == nil
            ? true
            : UserDefaults.standard.bool(forKey: "menubar.enabled")
        configureMenuBar(enabled: menuBarEnabled)
        if isUILab {
            configureUILab(arguments: ProcessInfo.processInfo.arguments)
            return
        }
        if await api.restoredUserId() != nil {
            do {
                let response: NativeMeResponse = try await api.request(.me)
                user = response.user
                destination = .inbox
            } catch {
                resetUserScopedState()
            }
        }
        await reload()
    }

    func select(_ next: Destination) {
        guard !next.requiresLogin || user != nil else { showsLogin = true; return }
        destination = next
        selectedArticle = nil
        articleDetail = nil
        focusReading = false
        if [.inbox, .favorites, .archive, .published].contains(next) { Task { await reload() } }
        if next == .tasks { Task { await loadJobs() } }
    }

    func login(username: String, password: String) async -> Bool {
        isLoading = true; errorMessage = nil
        defer { isLoading = false }
        do {
            let response = try await api.login(username: username, password: password)
            resetUserScopedState()
            user = response.user
            destination = .inbox
            showsLogin = false
            await reload()
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func logout() async {
        await api.logout()
        resetUserScopedState()
        await reload()
    }

    func resetUserScopedState() {
        user = nil
        counts = ArticleCounts(inbox: 0, favorites: 0, archive: 0, published: 0)
        articles = []
        selectedArticle = nil
        articleDetail = nil
        articleOfflineFile = nil
        jobs = []
        refreshMenuBarJobs()
        archiveSources = []
        selectedCategory = nil
        searchQuery = ""
        pagination = LibraryPagination()
        isOfflineCache = false
        isDownloadingOffline = false
        isLoadingDetail = false
        focusReading = false
        isLocked = false
        destination = .published
        PendingCollectPresentation.shared.request = nil
    }

    func reload() async {
        guard [.inbox, .favorites, .archive, .published].contains(destination) else { return }
        errorMessage = nil
        let scope = libraryCacheScope()
        let cached = loadCachedLibrary(scope: scope)
        if let cached {
            articles = cached.articles
            pagination.reset(totalPages: cached.totalPages)
            isOfflineCache = true
        }
        isLoading = cached == nil
        defer { isLoading = false }
        do {
            let view = destination.rawValue
            let response: ArticleListResponse
            if searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                response = try await api.request(.articles(view: view, page: 1, perPage: 20, sort: nil, order: sortOrder, category: selectedCategory), authenticated: destination != .published || user != nil)
            } else {
                response = try await api.request(.search(query: searchQuery, page: 1, perPage: 20), authenticated: user != nil)
            }
            articles = response.articles
            pagination.reset(totalPages: response.totalPages)
            saveCachedLibrary(response, scope: scope)
            if destination == .archive, user != nil {
                archiveSources = (try? await api.request(.sources)) ?? []
            }
            if user != nil {
                counts = try await api.request(.counts)
            } else {
                counts = ArticleCounts(inbox: 0, favorites: 0, archive: 0, published: response.total)
            }
            isOfflineCache = false
        } catch {
            if cached == nil {
                errorMessage = error.localizedDescription
            } else {
                isOfflineCache = true
            }
        }
    }

    private func libraryCacheScope() -> LibraryCacheScope {
        LibraryCacheScope(
            userId: user?.id ?? 0,
            view: destination.rawValue,
            query: searchQuery,
            order: sortOrder,
            category: selectedCategory
        )
    }

    private func loadCachedLibrary(scope: LibraryCacheScope) -> ArticleListResponse? {
        guard let context = modelContext else { return nil }
        return try? LibraryCacheStore(context: context).load(scope: scope)
    }

    private func saveCachedLibrary(_ response: ArticleListResponse, scope: LibraryCacheScope) {
        guard let context = modelContext else { return }
        try? LibraryCacheStore(context: context).save(response, scope: scope)
    }

    func open(_ article: ArticleCard) async {
        selectedArticle = article; articleDetail = nil; articleOfflineFile = nil; isLoadingDetail = true; errorMessage = nil
        defer { isLoadingDetail = false }
        do {
            if user == nil, let publicId = article.publicId {
                let response: PublicArticleResponse = try await api.request(.publication(publicId: publicId), authenticated: false)
                articleDetail = response.article
            } else {
                articleDetail = try await api.request(.article(id: article.id), authenticated: user != nil)
            }
        } catch {
            if let userId = user?.id, let offline = try? await offlineStore.package(articleId: article.id, userId: userId) {
                articleDetail = offline.manifest.article
                articleOfflineFile = offline.htmlFile
                isOfflineCache = true
            } else {
                errorMessage = error.localizedDescription
            }
        }
    }

    func downloadCurrentArticle() async {
        guard let detail = articleDetail, let userId = user?.id else { errorMessage = "请先登录后下载离线内容"; return }
        isDownloadingOffline = true
        defer { isDownloadingOffline = false }
        do {
            let package = try await offlineStore.download(article: detail, userId: userId)
            articleOfflineFile = package.htmlFile
        } catch { errorMessage = error.localizedDescription }
    }


    func loadMore() async {
        guard !isLoadingMore, let next = pagination.nextPage() else { return }
        isLoadingMore = true
        defer { isLoadingMore = false }
        do {
            let response: ArticleListResponse
            if searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                response = try await api.request(.articles(view: destination.rawValue, page: next, perPage: 20, sort: nil, order: sortOrder, category: selectedCategory), authenticated: destination != .published || user != nil)
            } else {
                response = try await api.request(.search(query: searchQuery, page: next, perPage: 20), authenticated: user != nil)
            }
            articles.append(contentsOf: response.articles.filter { item in !articles.contains(where: { $0.id == item.id }) })
            let merged = ArticleListResponse(articles: articles, total: response.total, page: response.page, perPage: response.perPage, totalPages: response.totalPages)
            saveCachedLibrary(merged, scope: libraryCacheScope())
        } catch { pagination = LibraryPagination(page: max(1, next - 1), totalPages: pagination.totalPages); errorMessage = error.localizedDescription }
    }

    func deleteCurrentArticle(permanently: Bool) async {
        guard let detail = articleDetail else { return }
        do {
            let endpoint: APIEndpoint = permanently ? .deleteArticlePermanently(id: detail.id) : .deleteArticle(id: detail.id)
            let _: DiscardResponse = try await api.request(endpoint, method: .delete)
            articles.removeAll { $0.id == detail.id }
            selectedArticle = nil; articleDetail = nil; articleOfflineFile = nil
            await reload()
        } catch { errorMessage = error.localizedDescription }
    }

    func performArticleAction(_ action: String) async {
        guard let detail = articleDetail else { return }
        do {
            switch action {
            case "favorite":
                struct Response: Codable, Sendable { let articleId: Int; let isFavorited: Bool }
                let _: Response = try await api.request(.articleAction(id: detail.id, action: "favorite"), method: .post)
            case "archive":
                struct Response: Codable, Sendable { let articleId: Int; let isArchived: Bool }
                let endpointAction = detail.isArchived ? "unarchive" : "archive"
                let _: Response = try await api.request(.articleAction(id: detail.id, action: endpointAction), method: .post)
            case "publish":
                struct Response: Codable, Sendable { let article: ArticleDetail; let publicUrl: String? }
                let endpointAction = detail.isPublished ? "unpublish" : "publish"
                let _: Response = try await api.request(.articleAction(id: detail.id, action: endpointAction), method: .post)
            case "refetch", "regenerate-ai":
                let _: DiscardResponse = try await api.request(.articleAction(id: detail.id, action: action), method: .post)
            default: break
            }
            await open(selectedArticle!)
            await reload()
        } catch { errorMessage = error.localizedDescription }
    }

    func submitCollect(url: URL, source: CollectEntrySource = .manual) async -> Bool {
        do {
            let response = try await api.submitCollect(url: url, source: source)
            jobs.insert(response.job, at: 0)
            refreshMenuBarJobs()
            showsCollect = false
            return true
        } catch {
            if PendingCollectPolicy.shouldQueue(error), let context = modelContext, let userId = user?.id {
                context.insert(PendingCollectRecord(userId: userId, url: url.absoluteString, source: source.rawValue))
                try? context.save()
                errorMessage = "当前网络不可用，链接已加入待提交队列"
                return true
            }
            errorMessage = error.localizedDescription
            return false
        }
    }

    func submitCollect(urls: [URL], source: CollectEntrySource = .manual) async -> Bool {
        guard !urls.isEmpty else { return false }
        var allSucceeded = true
        for url in urls {
            if !(await submitCollect(url: url, source: source)) { allSucceeded = false }
        }
        if allSucceeded { showsCollect = false }
        return allSucceeded
    }

    func configureMenuBar(enabled: Bool) {
        UserDefaults.standard.set(enabled, forKey: "menubar.enabled")
        menuBarController.setEnabled(
            enabled,
            jobs: jobs,
            onQuickCollect: { [weak self] in
                self?.showsCollect = true
                SystemActionRouter.shared.revealMainWindow()
            },
            onOpenMain: { SystemActionRouter.shared.revealMainWindow() },
            onOpenTasks: { [weak self] in
                self?.select(.tasks)
                SystemActionRouter.shared.revealMainWindow()
            }
        )
    }

    private func refreshMenuBarJobs() {
        menuBarController.update(jobs: jobs)
    }

    func configureGlobalShortcut(id: String?) {
        let descriptor = GlobalShortcutDescriptor.preset(id: id)
        UserDefaults.standard.set(descriptor.id, forKey: "globalShortcut.id")
        globalHotKeyManager.register(descriptor) { [weak self] in
            self?.showsCollect = true
            SystemActionRouter.shared.revealMainWindow()
        }
    }

    func retryPendingCollects() async {
        guard let context = modelContext, let userId = user?.id else { return }
        let records = (try? context.fetch(FetchDescriptor<PendingCollectRecord>()))?.filter { $0.userId == userId } ?? []
        for record in records {
            guard let url = URL(string: record.url), let source = CollectEntrySource(rawValue: record.source) else { context.delete(record); continue }
            do {
                _ = try await api.submitCollect(url: url, source: source)
                context.delete(record)
            } catch {
                record.lastError = error.localizedDescription
                if !PendingCollectPolicy.shouldQueue(error) { context.delete(record) }
            }
        }
        try? context.save()
        await loadJobs()
    }

    func loadJobs() async {
        do {
            let response: CollectJobsResponse = try await api.request(.collectJobs(limit: 50, offset: 0))
            jobs = response.jobs
            refreshMenuBarJobs()
        } catch { errorMessage = error.localizedDescription }
    }


    func retryJob(_ job: CollectJob) async {
        do { let response: CollectJobResponse = try await api.request(.retryCollectJob(id: job.id), method: .post); if let index = jobs.firstIndex(where: { $0.id == job.id }) { jobs[index] = response.job }; refreshMenuBarJobs() } catch { errorMessage = error.localizedDescription }
    }

    func deleteJob(_ job: CollectJob) async {
        do { let _: CollectDeleteResponse = try await api.request(.deleteCollectJob(id: job.id), method: .delete); jobs.removeAll { $0.id == job.id }; refreshMenuBarJobs() } catch { errorMessage = error.localizedDescription }
    }

    func clearFinishedJobs() async {
        do { let _: CollectDeleteResponse = try await api.request(.clearCollectJobs, method: .delete); await loadJobs() } catch { errorMessage = error.localizedDescription }
    }

    func handleDeepLink(_ url: URL) {
        do {
            let request: IncomingCollectRequest
            switch try IncomingCollectRouter.parseDeepLinkTarget(url) {
            case let .inline(inlineRequest):
                request = inlineRequest
            case let .sharedPayload(id):
                guard let payload = try SharedCollectStore.appGroup().consume(id: id) else {
                    throw IncomingCollectError.invalidSharedPayload
                }
                request = payload.collectRequest
                guard !request.urls.isEmpty else { throw IncomingCollectError.noWebURL }
            }
            PendingCollectPresentation.shared.request = request
            showsCollect = true
            SystemActionRouter.shared.revealMainWindow()
        } catch { errorMessage = error.localizedDescription }
    }
}

@MainActor
@Observable
final class PendingCollectPresentation {
    static let shared = PendingCollectPresentation()
    var request: IncomingCollectRequest?
}
