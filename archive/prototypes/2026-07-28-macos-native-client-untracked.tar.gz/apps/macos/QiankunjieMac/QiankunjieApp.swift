import SwiftData
import SwiftUI

@main
struct QiankunjieApp: App {
    @State private var model = AppModel()

    var body: some Scene {
        WindowGroup("乾坤戒", id: "main") {
            RootView()
                .environment(model)
                .frame(minWidth: 900, minHeight: 640)
                .task { await model.start() }
                .onOpenURL { model.handleDeepLink($0) }
                .modelContainer(for: [CachedArticleRecord.self, CachedArticleListRecord.self, PendingCollectRecord.self, ReadingProgressRecord.self])
        }
        .defaultSize(width: 1360, height: 860)
        .commands { QiankunjieCommands(model: model) }

    }
}

struct QiankunjieCommands: Commands {
    let model: AppModel
    var body: some Commands {
        CommandMenu("乾坤戒") {
            Button("快速采集…") { model.showsCollect = true }.keyboardShortcut("s", modifiers: [.command, .option])
            Button("搜索文章") { model.select(.inbox) }.keyboardShortcut("k", modifiers: .command)
            Divider()
            Button("刷新") { Task { await model.reload() } }.keyboardShortcut("r", modifiers: .command)
            Button(model.focusReading ? "退出专注阅读" : "专注阅读") { model.focusReading.toggle() }
                .keyboardShortcut("f", modifiers: [.command, .shift])
                .disabled(model.articleDetail == nil)
        }
    }
}
