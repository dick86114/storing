# 乾坤戒 macOS 原生客户端

Swift 6 + SwiftUI 的 Apple Silicon / macOS 26 自用客户端。固定连接：
`https://storing.idickies.com/api/v1`。

## 工程生成与测试

```bash
brew install xcodegen
pnpm macos:generate
pnpm macos:test
pnpm macos:build
```

Xcode 工程由 `project.yml` 生成。修改 target、Entitlement 或 Info.plist 设置后，应重新执行 `pnpm macos:generate`；生成的 `Qiankunjie.xcodeproj` 也纳入版本控制，方便直接打开。

## 本地运行

```bash
open apps/macos/Qiankunjie.xcodeproj
```

选择 `QiankunjieMac` scheme。首次运行时使用本机 Development Team 签名，以启用 Share Extension、App Group 和登录时启动。未签名构建只能验证主应用界面与纯本地逻辑。


## 系统集成

- Share Extension 会把所有分享文本与 URL 写入 App Group 一次性载荷，主应用统一提取、去重并允许多选后提交。
- 全局快速采集默认是 `⌥⌘S`，可在设置中切换为 `⇧⌘S` 或 `⌃⌥S`。
- “在菜单栏显示”通过 AppKit `NSStatusItem` 动态控制菜单栏入口；关闭主窗口后应用仍可常驻，菜单内显示快速采集和最近任务。
- “登录时启动”通过 `SMAppService.mainApp` 管理；若显示“需要批准”，请到系统设置的登录项中允许乾坤戒。

## Chromium 扩展

在 Chromium 浏览器扩展管理页启用开发者模式，选择“加载已解压的扩展”，目录为：

```text
apps/macos/ChromiumExtension
```

扩展只把当前页标题和 URL 交给 `qiankunjie://collect`，不保存 Token。

## 安全边界

- Refresh Token 存 Keychain；Access Token 由 `APIClient` 管理。
- 受控 WKWebView 关闭 JavaScript，外部链接交给默认浏览器。
- Share/Chromium 入口必须经过原生确认窗。
- 诊断导出不包含 Token、密码、MCP Key 或文章正文。

## UI Lab

UI Lab 不读取真实账号、Keychain、缓存或网络：

```bash
./scripts/macos-ui-lab.sh library    # 列表：左图右文
./scripts/macos-ui-lab.sh waterfall  # 瀑布流：竖向上图下字，自适应 1–4 列
./scripts/macos-ui-lab.sh card       # 卡片：横向矮胖，自适应 1–3 列
./scripts/macos-ui-lab.sh reader     # 阅读器：中栏自动收紧为列表
./scripts/macos-ui-lab.sh empty
./scripts/macos-ui-lab.sh loading
./scripts/macos-ui-lab.sh offline
./scripts/macos-ui-lab.sh login
```


## 资料库展示模式

- **列表**：左图右文；显示来源、标题、摘要与最多三个标签。
- **瀑布流**：竖向上图下字。单卡目标宽度为 `220–300 pt`、封面宽高比为 `0.75:1`，最多四列；每张卡都保留封面或渐变占位、来源、最多三行标题和一个标签。窗口变宽时优先增加列数，不拉宽卡片。
- **卡片**：横向矮胖的上封面下文卡。单卡目标宽度为 `360–520 pt`、封面宽高比为 `2.35:1`，最多三列；标题、摘要与最多三个标签位于封面下方。
- 当用户选中文章并展开阅读器时，中栏始终自动切换为紧凑的左图右文列表，避免大卡片压缩正文区域。

## 资料库缓存

文章列表只缓存 `ArticleCard` 元数据，不保存完整正文。缓存作用域包含 `userId`、资料库、搜索词、排序和来源筛选；启动或切换页面时先显示缓存，再后台刷新。账号切换会立即清空内存中的文章、任务、计数和筛选，其他账号的缓存不会被读取。

## 离线内容

离线包保存在 App Sandbox 的 Application Support 目录，按 `userId/articleId` 隔离。正文图片和封面先下载到 staging 目录，完成后再交付；网络中断不会留下可见的半成品。
