import Foundation

struct SharedCollectPayload: Codable, Equatable, Sendable {
    let values: [String]
    let title: String?
    let createdAt: Date

    init(values: [String], title: String?, createdAt: Date = .now) {
        self.values = values
        let normalizedTitle = title?.trimmingCharacters(in: .whitespacesAndNewlines)
        self.title = normalizedTitle?.isEmpty == false ? normalizedTitle : nil
        self.createdAt = createdAt
    }
}

enum SharedCollectStoreError: LocalizedError {
    case appGroupUnavailable

    var errorDescription: String? {
        switch self {
        case .appGroupUnavailable: "无法访问乾坤戒共享容器，请确认应用已使用同一开发团队签名"
        }
    }
}

struct SharedCollectStore {
    static let appGroupIdentifier = "group.com.idickies.storing.macos"
    private let root: URL
    private let fileManager: FileManager

    init(root: URL, fileManager: FileManager = .default) {
        self.root = root
        self.fileManager = fileManager
    }

    static func appGroup(fileManager: FileManager = .default) throws -> SharedCollectStore {
        guard let container = fileManager.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) else {
            throw SharedCollectStoreError.appGroupUnavailable
        }
        return SharedCollectStore(root: container.appending(path: "IncomingCollect", directoryHint: .isDirectory), fileManager: fileManager)
    }

    func save(_ payload: SharedCollectPayload) throws -> UUID {
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        let id = UUID()
        let data = try Self.encoder.encode(payload)
        try data.write(to: fileURL(for: id), options: .atomic)
        return id
    }

    func consume(id: UUID) throws -> SharedCollectPayload? {
        let url = fileURL(for: id)
        guard fileManager.fileExists(atPath: url.path) else { return nil }
        defer { try? fileManager.removeItem(at: url) }
        return try Self.decoder.decode(SharedCollectPayload.self, from: Data(contentsOf: url))
    }

    func removeExpired(olderThan cutoff: Date) throws {
        guard let files = try? fileManager.contentsOfDirectory(at: root, includingPropertiesForKeys: [.contentModificationDateKey]) else { return }
        for file in files {
            let values = try? file.resourceValues(forKeys: [.contentModificationDateKey])
            if let modified = values?.contentModificationDate, modified < cutoff {
                try? fileManager.removeItem(at: file)
            }
        }
    }

    private static var encoder: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .secondsSince1970
        return encoder
    }

    private static var decoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .secondsSince1970
        return decoder
    }

    private func fileURL(for id: UUID) -> URL {
        root.appending(path: "\(id.uuidString.lowercased()).json")
    }
}
