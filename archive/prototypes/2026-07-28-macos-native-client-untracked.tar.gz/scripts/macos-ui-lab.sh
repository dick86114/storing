#!/usr/bin/env bash
set -euo pipefail
SCENARIO="${1:-library}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
pnpm macos:build >/dev/null
pkill -x QiankunjieMac 2>/dev/null || true
APP="$HOME/Library/Developer/Xcode/DerivedData/Qiankunjie-btxutojevmwrnuhbcxgejqyyefnr/Build/Products/Debug/QiankunjieMac.app"
sleep 1
open -n "$APP" --args --ui-lab "--ui-lab-scenario=$SCENARIO"
echo "Opened UI Lab scenario: $SCENARIO"
